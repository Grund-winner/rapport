// ═══════════════════════════════════════════════════════════════════
// EDGE MIDDLEWARE - Mur d'accès EURO54 (multi-projets)
// Vérifie la DB via l'API Code Ghost centralisée
// Les API et services restent TOUJOURS actifs
// ═══════════════════════════════════════════════════════════════════

const STATUS_API = 'https://code-ghost-deploy.vercel.app/api/access-wall?action=status';

const BYPASS_PREFIXES = ['/api/', '/_next/', '/images/', '/download/', '/skills/'];
const BYPASS_EXACT = ['/suspended.html', '/suspended', '/favicon.ico', '/robots.txt', '/sitemap.xml'];
const STATIC_EXT = ['.js', '.css', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.woff', '.woff2', '.ttf', '.webp', '.json', '.xml'];

function shouldBypass(pathname) {
  if (BYPASS_PREFIXES.some(p => pathname.startsWith(p))) return true;
  if (BYPASS_EXACT.some(p => pathname === p)) return true;
  if (STATIC_EXT.some(ext => pathname.endsWith(ext))) return true;
  return false;
}

let cachedSuspended = false;
let cacheTime = 0;
const CACHE_TTL = 15000;

export const config = {
  matcher: ['/((?!api|_next|images|favicon\\.ico|download|skills).*)'],
};

async function checkWallStatus() {
  const now = Date.now();
  if (now - cacheTime < CACHE_TTL) return cachedSuspended;
  try {
    const resp = await fetch(STATUS_API, {
      headers: { 'x-internal-check': 'true' }
    });
    if (resp.ok) {
      const data = await resp.json();
      cachedSuspended = data.success && data.data && data.data.isSuspended === true;
      cacheTime = now;
      return cachedSuspended;
    }
  } catch (e) {
    console.error('[AccessWall] API check failed:', e.message);
  }
  return cachedSuspended;
}

export default async function middleware(request) {
  const url = new URL(request.url);
  const pathname = url.pathname;

  if (shouldBypass(pathname)) {
    const response = await fetch(request);
    response.headers.set('x-access-wall', 'bypass');
    return response;
  }

  const isSuspended = await checkWallStatus();

  if (isSuspended) {
    const suspendedUrl = new URL('/suspended.html', request.url);
    return new Response(null, {
      status: 302,
      headers: {
        'Location': suspendedUrl.href,
        'x-access-wall': 'suspended',
        'Cache-Control': 'no-store',
      }
    });
  }

  const response = await fetch(request);
  response.headers.set('x-access-wall', 'active');
  return response;
}
