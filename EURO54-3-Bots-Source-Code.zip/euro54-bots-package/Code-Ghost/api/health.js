module.exports = async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    if (req.method === 'OPTIONS') return res.status(200).end();

    const status = {
        service: 'JET HACK Bot',
        status: 'online',
        timestamp: new Date().toISOString(),
        version: '1.1.0'
    };

    try {
        const { query } = require('../lib/db');
        await query('SELECT 1');
        status.database = 'connected';
    } catch (e) {
        status.database = 'error: ' + e.message;
    }

    res.status(200).json(status);
};
