// ═══════════════════════════════════════════════════════
// CODE GHOST - Postback Registration avec notifications admin
// 1Win appelle cette URL quand un utilisateur s'inscrit
// Route : GET /api/postback-register
// ═══════════════════════════════════════════════════════
const { query } = require('../lib/db');

// === NOTIFICATION TELEGRAM INSCRIPTIONS ===
const NOTIF_BOT_TOKEN = process.env.NOTIF_BOT_TOKEN || '';
const ADMIN_CHAT_IDS = (process.env.ADMIN_CHAT_IDS || '').split(',').map(s => s.trim()).filter(Boolean);

async function sendNotif(chatId, text) {
    if (!NOTIF_BOT_TOKEN || !chatId) {
        console.warn('[NOTIF REG] skip: token ou chatId manquant');
        return { ok: false, reason: 'missing_token_or_chatid' };
    }
    try {
        const res = await fetch('https://api.telegram.org/bot' + NOTIF_BOT_TOKEN + '/sendMessage', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId, text: text })
        });
        let data = null;
        try { data = await res.json(); } catch (_) {}
        if (res.ok && data && data.ok) {
            console.log('[NOTIF REG] OK pour chat_id=' + chatId);
            return { ok: true };
        }
        console.error('[NOTIF REG] ÉCHEC pour chat_id=' + chatId + ' | HTTP=' + res.status);
        return { ok: false, reason: 'telegram_error', http: res.status };
    } catch (e) {
        console.error('[NOTIF REG] EXCEPTION pour chat_id=' + chatId + ' :', e.message);
        return { ok: false, reason: 'network' };
    }
}

module.exports = async function handler(req, res) {
    try {
        const clickid = req.query.clickid || null;
        const userId1win = req.query.user_id;
        const hash = req.query.hash;
        const country = req.query.country;

        if (!userId1win) return res.status(400).send('Missing user_id');
        console.log('[POSTBACK REG] clickid=' + clickid + ', user_id=' + userId1win + ', hash=' + hash);

        if (clickid) {
            const existing = await query('SELECT * FROM users WHERE telegram_id = $1', [clickid]);
            if (existing.length > 0) {
                await query(
                    'UPDATE users SET is_registered = TRUE, one_win_user_id = $1, registered_at = NOW(), updated_at = NOW() WHERE telegram_id = $2',
                    [userId1win, clickid]
                );
            } else {
                await query(
                    'INSERT INTO users (telegram_id, one_win_user_id, is_registered, created_at, updated_at) VALUES ($1, $2, TRUE, NOW(), NOW())',
                    [clickid, userId1win]
                );
            }
        } else {
            const existing = await query('SELECT * FROM users WHERE one_win_user_id = $1', [userId1win]);
            if (existing.length === 0) {
                await query(
                    'INSERT INTO users (one_win_user_id, is_registered, created_at, updated_at) VALUES ($1, TRUE, NOW(), NOW())',
                    [userId1win]
                );
            } else {
                await query(
                    'UPDATE users SET is_registered = TRUE, registered_at = NOW(), updated_at = NOW() WHERE one_win_user_id = $1',
                    [userId1win]
                );
            }
        }

        // Envoi notification d'inscription aux admins (format compact)
        if (ADMIN_CHAT_IDS.length > 0 && NOTIF_BOT_TOKEN) {
            var notif = userId1win + '\n' + (country ? ('Pays : ' + country) : 'Pays : Inconnu');
            for (const chatId of ADMIN_CHAT_IDS) {
                await sendNotif(chatId, notif);
            }
        } else {
            console.warn('[NOTIF REG] Aucun envoi — ADMIN_CHAT_IDS vide ou NOTIF_BOT_TOKEN manquant');
        }

        res.status(200).send('OK');
    } catch (error) {
        console.error('[POSTBACK REG ERROR]', error);
        res.status(500).send('Error: ' + error.message);
    }
};
