// ═══════════════════════════════════════════════════════
// CODE GHOST - Postback Deposit avec notifications admin
// 1Win appelle cette URL quand un utilisateur fait un dépôt
// Route : GET /api/postback-deposit
// ═══════════════════════════════════════════════════════
const { query } = require('../lib/db');
const MIN_DEPOSIT = parseFloat(process.env.MIN_DEPOSIT) || 8.5;

// === NOTIFICATION TELEGRAM DEPOTS ===
const NOTIF_BOT_TOKEN = process.env.NOTIF_BOT_TOKEN || '';
const ADMIN_CHAT_IDS = (process.env.ADMIN_CHAT_IDS || '').split(',').map(s => s.trim()).filter(Boolean);

async function sendNotif(chatId, text) {
    if (!NOTIF_BOT_TOKEN || !chatId) {
        console.warn('[NOTIF] skip: token ou chatId manquant');
        return { ok: false, reason: 'missing_token_or_chatid' };
    }
    try {
        const res = await fetch('https://api.telegram.org/bot' + NOTIF_BOT_TOKEN + '/sendMessage', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId, text: text })
        });
        let data = null;
        try { data = await res.json(); } catch (_) {}
        if (res.ok && data && data.ok) {
            console.log('[NOTIF] OK pour chat_id=' + chatId);
            return { ok: true };
        }
        console.error('[NOTIF] ÉCHEC pour chat_id=' + chatId + ' | HTTP=' + res.status);
        return { ok: false, reason: 'telegram_error', http: res.status };
    } catch (e) {
        console.error('[NOTIF] EXCEPTION pour chat_id=' + chatId + ' :', e.message);
        return { ok: false, reason: 'network' };
    }
}

module.exports = async function handler(req, res) {
    const queryStr = JSON.stringify(req.query);
    console.log('[POSTBACK DEP] ▶ REQUÊTE method=' + req.method + ' query=' + queryStr);
    console.log('[POSTBACK DEP] NOTIF_BOT_TOKEN présent ?', !!NOTIF_BOT_TOKEN, 'ADMIN_CHAT_IDS =', JSON.stringify(ADMIN_CHAT_IDS));

    try {
        const clickid = req.query.clickid || req.query.sub1 || req.query.sub_1 || null;
        const userId1win = req.query.user_id || req.query.userid || req.query.player_id;
        const amount = parseFloat(req.query.amount) || 0;
        const transactionId = req.query.transactionid || req.query.transaction_id || req.query.txn;

        if (!userId1win) {
            console.error('[POSTBACK DEP] ❌ Missing user_id');
            return res.status(400).send('Missing user_id');
        }
        console.log('[POSTBACK DEP] clickid=' + clickid + ', user_id=' + userId1win + ', amount=' + amount);

        let total = amount;

        if (clickid) {
            const existing = await query('SELECT * FROM users WHERE telegram_id = $1', [clickid]);
            if (existing.length > 0) {
                const user = existing[0];
                total = parseFloat(user.deposit_amount || 0) + amount;
                const ok = total >= MIN_DEPOSIT;
                await query(
                    'UPDATE users SET is_deposited = $1, deposit_amount = $2, one_win_user_id = $3, is_registered = TRUE, deposited_at = CASE WHEN $1 THEN NOW() ELSE deposited_at END, updated_at = NOW() WHERE telegram_id = $4',
                    [ok, total, userId1win, clickid]
                );
            } else {
                const ok = amount >= MIN_DEPOSIT;
                await query(
                    'INSERT INTO users (telegram_id, one_win_user_id, is_registered, is_deposited, deposit_amount, deposited_at, created_at, updated_at) VALUES ($1, $2, TRUE, $3, $4, CASE WHEN $3 THEN NOW() ELSE NULL END, NOW(), NOW())',
                    [clickid, userId1win, ok, amount]
                );
            }
        } else {
            const existing = await query('SELECT * FROM users WHERE one_win_user_id = $1', [userId1win]);
            if (existing.length > 0) {
                const user = existing[0];
                total = parseFloat(user.deposit_amount || 0) + amount;
                const ok = total >= MIN_DEPOSIT;
                await query(
                    'UPDATE users SET is_deposited = $1, deposit_amount = $2, is_registered = TRUE, deposited_at = CASE WHEN $1 THEN NOW() ELSE deposited_at END, updated_at = NOW() WHERE one_win_user_id = $3',
                    [ok, total, userId1win]
                );
            } else {
                const ok = amount >= MIN_DEPOSIT;
                await query(
                    'INSERT INTO users (one_win_user_id, is_registered, is_deposited, deposit_amount, deposited_at, created_at, updated_at) VALUES ($1, TRUE, $2, $3, CASE WHEN $2 THEN NOW() ELSE NULL END, NOW(), NOW())',
                    [userId1win, ok, amount]
                );
            }
        }

        // Envoi notification aux admins (format compact)
        if (ADMIN_CHAT_IDS.length > 0 && NOTIF_BOT_TOKEN) {
            const notif = 'ID : ' + userId1win + '\nMontant: $' + amount.toFixed(2) + '\nTotal:$' + total.toFixed(2);
            for (const chatId of ADMIN_CHAT_IDS) {
                await sendNotif(chatId, notif);
            }
        } else {
            console.warn('[NOTIF] Aucun envoi — ADMIN_CHAT_IDS vide ou NOTIF_BOT_TOKEN manquant');
        }

        res.status(200).send('OK');
    } catch (error) {
        console.error('[POSTBACK DEP ERROR]', error);
        res.status(500).send('Error');
    }
};
