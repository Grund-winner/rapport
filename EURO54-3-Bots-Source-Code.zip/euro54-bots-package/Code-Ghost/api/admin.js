// ═══════════════════════════════════════════════════════
// EURO54 - Admin API (Code Ghost - Panneau unique)
// Route : GET /api/admin
// Calcule les dépôts depuis la table deposits (pas users.deposit_amount)
// ═══════════════════════════════════════════════════════
const { query, sbGetAll, sbGet } = require('../lib/db');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'euro54admin';

module.exports = async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.query.password !== ADMIN_PASSWORD) return res.status(403).json({ error: 'Non autorise' });

    try {
        const action = req.query.action;

        // ─── Stats ───
        if (!action || action === 'stats') {
            // Users counts via Supabase REST (pagination-safe)
            const t = await query('SELECT COUNT(*) as c FROM users');
            const r = await query('SELECT COUNT(*) as c FROM users WHERE is_registered = TRUE');
            const d = await query('SELECT COUNT(*) as c FROM users WHERE is_deposited = TRUE');
            const today = await query('SELECT COUNT(*) as c FROM users WHERE created_at >= CURRENT_DATE');
            const todayDep = await query('SELECT COUNT(*) as c FROM users WHERE deposited_at >= CURRENT_DATE');

            // Total dépôts: depuis la table deposits si elle contient des données,
            // sinon fallback sur users.deposit_amount
            let totalRevenue = 0;
            let depositCount = 0;
            try {
                const allDeposits = await sbGetAll('deposits?select=amount');
                if (allDeposits.length > 0) {
                    for (var i = 0; i < allDeposits.length; i++) {
                        totalRevenue += parseFloat(allDeposits[i].amount) || 0;
                    }
                    depositCount = allDeposits.length;
                    console.log('[ADMIN STATS] Total depots (table deposits): ' + depositCount + ' enregistrements = $' + totalRevenue.toFixed(2));
                } else {
                    // deposits table vide → fallback sur users.deposit_amount
                    console.log('[ADMIN STATS] Table deposits vide, fallback sur users.deposit_amount');
                    const allUsers = await sbGetAll('users?select=deposit_amount');
                    for (var j = 0; j < allUsers.length; j++) {
                        var amt = parseFloat(allUsers[j].deposit_amount) || 0;
                        if (amt > 0) {
                            totalRevenue += amt;
                            depositCount++;
                        }
                    }
                    console.log('[ADMIN STATS] Fallback users.deposit_amount: ' + depositCount + ' depots = $' + totalRevenue.toFixed(2));
                }
            } catch(depErr) {
                console.error('[ADMIN STATS] Erreur lecture deposits:', depErr.message);
                // Fallback: somme depuis users.deposit_amount
                const rev = await query('SELECT COALESCE(SUM(deposit_amount),0) as t FROM users');
                totalRevenue = parseFloat(rev[0].t) || 0;
                depositCount = parseInt(d[0].c) || 0;
                console.log('[ADMIN STATS] Fallback query users.deposit_amount: $' + totalRevenue.toFixed(2));
            }

            return res.status(200).json({
                total: parseInt(t[0].c),
                registered: parseInt(r[0].c),
                deposited: parseInt(d[0].c),
                totalRevenue: Math.round(totalRevenue * 100) / 100,
                depositCount: depositCount,
                newToday: parseInt(today[0].c),
                depositedToday: parseInt(todayDep[0].c)
            });
        }

        // ─── Tous les utilisateurs (avec pagination) ───
        if (action === 'users') {
            const users = await query('SELECT * FROM users ORDER BY created_at DESC');
            console.log('[ADMIN USERS] ' + users.length + ' utilisateurs charges');
            return res.status(200).json({ users });
        }

        // ─── Recherche utilisateur ───
        if (action === 'search') {
            const q = req.query.q || '';
            if (!q.trim()) return res.status(200).json({ users: [] });

            const searchTerm = '%' + q.trim() + '%';
            const users = await query(
                `SELECT * FROM users
                 WHERE telegram_id::text ILIKE $1
                    OR one_win_user_id::text ILIKE $1
                    OR first_name ILIKE $1
                    OR last_name ILIKE $1
                    OR username ILIKE $1
                 ORDER BY created_at DESC
                 LIMIT 50`,
                [searchTerm]
            );
            return res.status(200).json({ users });
        }

        // ─── Codes d'accès ───
        if (action === 'codes') {
            const codes = await query(
                'SELECT ac.*, u.first_name, u.username FROM access_codes ac LEFT JOIN users u ON u.telegram_id = ac.telegram_id ORDER BY ac.created_at DESC'
            );
            return res.status(200).json({ codes });
        }

        // ─── Générer un code ───
        if (action === 'generate') {
            const tid = req.query.telegram_id;
            const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
            let code = 'EURO-';
            for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
            await query('INSERT INTO access_codes (code, telegram_id, created_at) VALUES ($1, $2, NOW())', [code, tid || null]);
            return res.status(200).json({ success: true, code });
        }

        return res.status(400).json({ error: 'Action inconnue' });
    } catch (error) {
        console.error('[ADMIN API ERROR]', error);
        return res.status(500).json({ error: 'Erreur serveur: ' + error.message });
    }
};
