module.exports = async function handler(req, res) {
    res.status(200).json({
        service: 'JET HACK Bot',
        status: 'online',
        version: '1.1.0',
        endpoints: {
            webhook: '/api/webhook',
            health: '/api/health',
            postback_register: '/api/postback-register',
            postback_deposit: '/api/postback-deposit'
        }
    });
};
