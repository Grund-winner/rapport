// ═══════════════════════════════════════════════════════════════════
// API: Access Wall - Mur d'accès EURO54
// Route : /api/access-wall
// Gère le cycle 30 jours, la suspension et la réactivation
// ═══════════════════════════════════════════════════════════════════
//
// ENDPOINTS:
//   GET  /api/access-wall?action=status    → Statut du mur
//   GET  /api/access-wall?action=config     → Configuration
//   POST /api/access-wall?action=reactivate → Réactiver (clé admin requise)
//   POST /api/access-wall?action=force      → Forcer suspend/activate/reset (admin)
//   GET  /api/access-wall?action=cron       → Cron job Vercel (cycle auto)
// ═══════════════════════════════════════════════════════════════════

const { query } = require('../lib/db');

const ADMIN_KEY = process.env.ADMIN_REACTIVATION_KEY || 'euro54-admin-2024';
const CYCLE_DAYS = parseInt(process.env.WALL_CYCLE_DAYS || '30');
const GRACE_HOURS = parseInt(process.env.WALL_GRACE_HOURS || '24');

// ═══════════════════════════════════════════════════════
// Initialisation de la table dans la DB
// ═══════════════════════════════════════════════════════

async function initTable() {
  try {
    await query(`
      CREATE TABLE IF NOT EXISTS access_wall_state (
        id INTEGER PRIMARY KEY DEFAULT 1 CHECK (id = 1),
        activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        suspended_at TIMESTAMPTZ,
        reactivated_at TIMESTAMPTZ,
        reactivate_count INTEGER NOT NULL DEFAULT 0,
        is_active BOOLEAN NOT NULL DEFAULT true,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
    `);
    // Insérer la ligne initiale si elle n'existe pas
    await query(`
      INSERT INTO access_wall_state (id, activated_at, is_active)
      SELECT 1, NOW(), true
      WHERE NOT EXISTS (SELECT 1 FROM access_wall_state WHERE id = 1);
    `);
  } catch (err) {
    console.error('[AccessWall] Init table error:', err.message);
  }
}

// ═══════════════════════════════════════════════════════
// Actions
// ═══════════════════════════════════════════════════════

// → GET ?action=status
async function handleStatus() {
  try {
    await initTable();
    const rows = await query('SELECT * FROM access_wall_state WHERE id = 1');
    const state = rows[0];

    if (!state) {
      return {
        wallEnabled: true,
        isSuspended: false,
        activatedAt: new Date().toISOString(),
        suspendedAt: null,
        daysInCycle: 0,
        daysRemaining: CYCLE_DAYS,
        reactivateCount: 0,
        isGracePeriod: false,
        gracePeriodHours: 0,
        servicesRunning: true,
      };
    }

    const now = Date.now();
    const activated = new Date(state.activated_at).getTime();
    const cycleMs = CYCLE_DAYS * 24 * 60 * 60 * 1000;
    const elapsed = now - activated;
    const daysInCycle = Math.floor(elapsed / (24 * 60 * 60 * 1000));
    const daysRemaining = Math.max(0, CYCLE_DAYS - daysInCycle);
    const isSuspended = !state.is_active;
    const graceMs = GRACE_HOURS * 60 * 60 * 1000;
    const suspendedAt = state.suspended_at ? new Date(state.suspended_at).getTime() : null;
    const graceEnd = suspendedAt ? suspendedAt + graceMs : 0;
    const isGracePeriod = suspendedAt ? (now <= graceEnd) : false;
    const graceRemaining = isGracePeriod ? Math.max(0, Math.ceil((graceEnd - now) / (60 * 60 * 1000))) : 0;

    return {
      wallEnabled: true,
      isSuspended,
      activatedAt: state.activated_at,
      suspendedAt: state.suspended_at,
      reactivatedAt: state.reactivated_at,
      daysInCycle,
      daysRemaining,
      cycleDays: CYCLE_DAYS,
      reactivateCount: state.reactivate_count,
      isGracePeriod,
      gracePeriodHours: graceRemaining,
      servicesRunning: true, // Les services restent TOUJOURS actifs
    };
  } catch (err) {
    console.error('[AccessWall] Status error:', err.message);
    return { wallEnabled: true, isSuspended: false, error: err.message, servicesRunning: true };
  }
}

// → GET ?action=config
async function handleConfig() {
  return {
    cycleDays: CYCLE_DAYS,
    gracePeriodHours: GRACE_HOURS,
    securityFeatures: [
      'admin_key_reactivation',
      'cookie_based_status',
      'api_bypass_middleware',
      'db_persistent_state',
      'grace_period',
      'vercel_cron_support',
    ],
    protectedRoutes: ['/ (index)', '/admin', '/access', '/predictions', '/diagnostic'],
    exemptedRoutes: ['/api/*', '/_next/*', '/suspended.html', '/images/*'],
    apiEndpoints: {
      status: '/api/access-wall?action=status',
      config: '/api/access-wall?action=config',
      reactivate: '/api/access-wall?action=reactivate [POST]',
      force: '/api/access-wall?action=force [POST]',
      cron: '/api/access-wall?action=cron',
    },
    vercelCron: {
      enabled: true,
      schedule: '0 0 */30 * *', // Tous les 30 jours
      endpoint: '/api/access-wall?action=cron',
    },
    envVars: {
      ADMIN_REACTIVATION_KEY: 'Clé de réactivation admin',
      WALL_CYCLE_DAYS: 'Durée du cycle en jours (défaut: 30)',
      WALL_GRACE_HOURS: 'Période de grâce en heures (défaut: 24)',
    },
  };
}

// → POST ?action=reactivate
async function handleReactivate(req) {
  let body;
  try {
    body = await req.body;
  } catch {
    return { success: false, error: 'Body invalide' };
  }

  const { securityKey, confirmAction } = body || {};

  if (!securityKey || securityKey.length < 8) {
    return { success: false, error: 'Clé de sécurité requise (min. 8 caractères)' };
  }
  if (!confirmAction) {
    return { success: false, error: 'Vous devez confirmer la réactivation' };
  }
  if (securityKey !== ADMIN_KEY) {
    console.warn(`[AccessWall] FAILED reactivate attempt: ${securityKey.substring(0, 4)}...`);
    return { success: false, error: 'Clé de réactivation invalide' };
  }

  try {
    await initTable();
    const newActivated = new Date().toISOString();
    const newCount = await query(
      'UPDATE access_wall_state SET activated_at = $1, suspended_at = NULL, reactivated_at = $1, is_active = true, reactivate_count = reactivate_count + 1, updated_at = NOW() WHERE id = 1 RETURNING reactivate_count',
      [newActivated]
    );

    console.log(`[AccessWall] REACTIVATED at ${newActivated} (count: ${newCount[0].reactivate_count})`);

    return {
      success: true,
      message: 'Service réactivé avec succès',
      data: {
        reactivatedAt: newActivated,
        reactivateCount: newCount[0].reactivate_count,
        newCycleEnd: new Date(Date.now() + CYCLE_DAYS * 24 * 60 * 60 * 1000).toISOString(),
      },
    };
  } catch (err) {
    console.error('[AccessWall] Reactivate error:', err.message);
    return { success: false, error: 'Erreur lors de la réactivation: ' + err.message };
  }
}

// → POST ?action=force
async function handleForce(req) {
  let body;
  try {
    body = await req.body;
  } catch {
    return { success: false, error: 'Body invalide' };
  }

  const { action, adminKey } = body || {};

  if (adminKey !== ADMIN_KEY) {
    console.warn('[AccessWall] FAILED force attempt');
    return { success: false, error: 'Clé admin invalide' };
  }
  if (!['suspend', 'activate', 'reset'].includes(action)) {
    return { success: false, error: 'Action invalide: suspend, activate, ou reset' };
  }

  try {
    await initTable();
    const now = new Date().toISOString();

    if (action === 'suspend') {
      await query(
        'UPDATE access_wall_state SET suspended_at = $1, is_active = false, updated_at = NOW() WHERE id = 1',
        [now]
      );
      console.log(`[AccessWall] FORCE SUSPEND at ${now}`);
    } else if (action === 'activate') {
      await query(
        'UPDATE access_wall_state SET activated_at = $1, suspended_at = NULL, is_active = true, updated_at = NOW() WHERE id = 1',
        [now]
      );
      console.log(`[AccessWall] FORCE ACTIVATE at ${now}`);
    } else if (action === 'reset') {
      await query(
        'UPDATE access_wall_state SET activated_at = NOW(), suspended_at = NULL, reactivated_at = NULL, reactivate_count = 0, is_active = true, updated_at = NOW() WHERE id = 1'
      );
      console.log(`[AccessWall] FORCE RESET at ${now}`);
    }

    return {
      success: true,
      message: `Action "${action}" exécutée avec succès`,
      action,
      timestamp: now,
    };
  } catch (err) {
    console.error('[AccessWall] Force error:', err.message);
    return { success: false, error: 'Erreur: ' + err.message };
  }
}

// → GET ?action=cron (appelé par Vercel Cron)
async function handleCron() {
  try {
    await initTable();
    const rows = await query('SELECT * FROM access_wall_state WHERE id = 1');
    const state = rows[0];

    if (!state || !state.is_active) {
      return { success: true, message: 'Déjà suspendu ou non initialisé', skipped: true };
    }

    const now = Date.now();
    const activated = new Date(state.activated_at).getTime();
    const cycleMs = CYCLE_DAYS * 24 * 60 * 60 * 1000;

    if (now - activated >= cycleMs) {
      const suspendedAt = new Date().toISOString();
      await query(
        'UPDATE access_wall_state SET suspended_at = $1, is_active = false, updated_at = NOW() WHERE id = 1',
        [suspendedAt]
      );
      console.log(`[AccessWall] CRON: Service SUSPENDED at ${suspendedAt}`);
      return {
        success: true,
        message: 'Service suspendu par le cron (cycle de ' + CYCLE_DAYS + ' jours terminé)',
        suspendedAt,
        wasActive: true,
      };
    }

    const daysRemaining = Math.ceil((cycleMs - (now - activated)) / (24 * 60 * 60 * 1000));
    return {
      success: true,
      message: 'Cycle encore en cours',
      daysRemaining,
      suspendedAt: null,
      skipped: true,
    };
  } catch (err) {
    console.error('[AccessWall] Cron error:', err.message);
    return { success: false, error: err.message };
  }
}

// ═══════════════════════════════════════════════════════
// Handler principal
// ═══════════════════════════════════════════════════════

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-store, max-age=0');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const action = req.query.action || (req.method === 'GET' ? 'status' : null);

  try {
    let result;

    switch (action) {
      case 'status':
        result = await handleStatus();
        break;
      case 'config':
        result = await handleConfig();
        break;
      case 'reactivate':
        if (req.method !== 'POST') return res.status(405).json({ error: 'POST requis' });
        result = await handleReactivate(req);
        break;
      case 'force':
        if (req.method !== 'POST') return res.status(405).json({ error: 'POST requis' });
        result = await handleForce(req);
        break;
      case 'cron':
        result = await handleCron();
        break;
      default:
        return res.status(400).json({ error: 'Action invalide. Utilisez: status, config, reactivate, force, cron' });
    }

    // Si la réponse inclut un cookie de statut (pour le middleware)
    if (result.success !== undefined && !result.error) {
      if (result.action === 'suspend') {
        res.setHeader('Set-Cookie', 'euro54_wall_status=suspended; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=86400');
      } else if (result.action === 'activate' || result.action === 'reset' || action === 'reactivate') {
        res.setHeader('Set-Cookie', 'euro54_wall_status=active; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=' + (CYCLE_DAYS * 24 * 60 * 60));
      }
    }

    return res.status(200).json({ success: true, data: result });
  } catch (err) {
    console.error('[AccessWall] Handler error:', err.message);
    return res.status(500).json({ success: false, error: 'Erreur interne: ' + err.message });
  }
};
