// ═══════════════════════════════════════════════════════
// EURO54 - Verify 1Win ID
// Route : POST /api/verify-1win
// ═══════════════════════════════════════════════════════
const { query } = require('../lib/db');

module.exports = async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') return res.status(200).end();
    if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

    try {
        const { telegram_id, one_win_id } = req.body || {};
        if (!one_win_id || !one_win_id.toString().trim()) {
            return res.status(400).json({ success: false, message: 'Identifiant 1Win requis.' });
        }
        if (!telegram_id) {
            return res.status(400).json({ success: false, message: 'ID Telegram requis.' });
        }

        // Update user with 1Win ID and mark as registered
        await query(
            'UPDATE users SET one_win_user_id = $1, is_registered = TRUE, updated_at = NOW() WHERE telegram_id = $2',
            [String(one_win_id), String(telegram_id)]
        );

        // Check if already deposited
        const users = await query('SELECT deposit_amount, is_deposited FROM users WHERE telegram_id = $1', [String(telegram_id)]);
        const user = users[0];
        const totalDeposited = parseFloat(user?.deposit_amount) || 0;
        const MIN_DEPOSIT = parseFloat(process.env.MIN_DEPOSIT) || 8.5;

        if (totalDeposited >= MIN_DEPOSIT) {
            return res.status(200).json({ success: true, message: 'Accès VIP accordé !' });
        }

        return res.status(200).json({ success: false, message: 'Dépôt insuffisant. Effectuez un dépôt minimum de 8.5$ (5000 FCFA) pour accéder aux prédictions.' });

    } catch (error) {
        console.error('[VERIFY ERROR]', error);
        return res.status(500).json({ success: false, message: 'Erreur serveur.' });
    }
};
