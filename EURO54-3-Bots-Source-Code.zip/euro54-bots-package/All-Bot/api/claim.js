// ═══════════════════════════════════════════════════════
// EURO54 - Claim (Telegram one-time links)
// Route : GET /api/claim?token=XXX
// ═══════════════════════════════════════════════════════
const crypto = require('crypto');
const { query } = require('../lib/db');
const LINK_SECRET = process.env.ADMIN_PASSWORD || 'euro54secret';
const BOT_TYPE = process.env.BOT_TYPE || 'prediction';

function htmlRedirect(url) {
    return `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="icon" href="data:,">
<script>window.location.replace("${url}");</script>
<meta http-equiv="refresh" content="0;url=${url}">
</head><body><p>Redirection...</p><script>window.location.replace("${url}");</script></body></html>`;
}

module.exports = async function handler(req, res) {
    try {
        const token = req.query.token;

        // Si pas de token → page d'accès (PAS de bypass vers predictions)
        if (!token) {
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(htmlRedirect('/access'));
        }

        // Decode base64url token
        let decoded;
        try {
            decoded = Buffer.from(token, 'base64url').toString('utf8');
        } catch (e) {
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(htmlRedirect('/access'));
        }

        const parts = decoded.split(':');
        if (parts.length !== 3) {
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(htmlRedirect('/access'));
        }

        const [telegramId, expiresAt, sig] = parts;

        // Verify HMAC signature
        const expectedSig = crypto.createHmac('sha256', LINK_SECRET)
            .update(`${telegramId}:${expiresAt}`)
            .digest('hex').substring(0, 12);

        if (sig !== expectedSig) {
            console.error('[CLAIM] HMAC mismatch for user', telegramId);
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(htmlRedirect('/access'));
        }

        // Verify expiry (10 minutes)
        if (parseInt(expiresAt) < Date.now()) {
            console.error('[CLAIM] Token expired for user', telegramId);
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(htmlRedirect('/access'));
        }

        // ═══ CHECK DB : verify user has deposited ═══
        try {
            const users = await query('SELECT * FROM users WHERE telegram_id = $1', [telegramId]);
            const user = users[0];
            if (!user) {
                console.log('[CLAIM] User not found:', telegramId);
                res.setHeader('Content-Type', 'text/html');
                return res.status(200).send(htmlRedirect('/access'));
            }

            const MIN_DEPOSIT = parseFloat(process.env.MIN_DEPOSIT) || 8.5;
            const totalDeposited = parseFloat(user.deposit_amount) || 0;

            if (totalDeposited >= MIN_DEPOSIT) {
                console.log('[CLAIM] Access granted for user', telegramId, 'deposit:', totalDeposited, 'type:', BOT_TYPE);
                res.setHeader('Content-Type', 'text/html');
                if (BOT_TYPE === 'signals') {
                    return res.status(200).send(htmlRedirect('/signals?auth=ok'));
                }
                return res.status(200).send(htmlRedirect('/predictions?auth=ok'));
            } else {
                console.log('[CLAIM] Insufficient deposit for user', telegramId, ':', totalDeposited);
                res.setHeader('Content-Type', 'text/html');
                return res.status(200).send(htmlRedirect('/access'));
            }
        } catch (dbErr) {
            console.error('[CLAIM DB ERROR]', dbErr);
            res.setHeader('Content-Type', 'text/html');
            return res.status(200).send(htmlRedirect('/access'));
        }

    } catch (error) {
        console.error('[CLAIM ERROR]', error);
        res.setHeader('Content-Type', 'text/html');
        return res.status(200).send(htmlRedirect('/access'));
    }
};
