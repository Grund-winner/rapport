<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/src/bootstrap.php';

$resource = (string) ($_GET['resource'] ?? '');
$method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

if ($method === 'OPTIONS') {
    http_response_code(204);
    exit;
}

try {
    switch ($resource) {
        case 'games':
            rovas_handle_games($method);
            break;
        case 'game-page':
            rovas_handle_game_page();
            break;
        case 'serve-image':
            rovas_handle_image();
            break;
        case 'upload':
            rovas_handle_upload($method);
            break;
        default:
            rovas_error('Not found', 404);
    }
} catch (Throwable $error) {
    error_log('[ROVAS] ' . $error->getMessage());
    rovas_error('Internal server error', 500);
}

function rovas_handle_games(string $method): never
{
    if ($method === 'GET') {
        if (isset($_GET['status'])) {
            rovas_json_response([
                'success' => true,
                'configured' => rovas_admin_is_configured(),
                'setup_available' => rovas_env('ROVAS_SETUP_KEY') !== null,
            ]);
        }
        if (isset($_GET['read_html'])) {
            rovas_require_admin();
            $slug = rovas_safe_slug((string) $_GET['read_html']);
            if (!rovas_valid_slug($slug)) {
                rovas_error('Invalid slug', 400);
            }
            $path = rovas_game_html_path($slug);
            if (!is_file($path)) {
                rovas_error('HTML not found', 404);
            }
            rovas_json_response(['success' => true, 'html' => file_get_contents($path)]);
        }

        $games = rovas_read_games();
        if (isset($_GET['admin'])) {
            rovas_require_admin();
            rovas_json_response([
                'success' => true,
                'games' => rovas_admin_games($games),
                'csrf' => rovas_csrf_token(),
            ]);
        }

        rovas_json_response(['success' => true, 'games' => rovas_public_games($games)]);
    }

    if ($method !== 'POST') {
        rovas_error('Method not allowed', 405);
    }

    $body = rovas_request_body();
    $action = (string) ($body['action'] ?? '');

    if ($action === 'login') {
        rovas_rate_limit('admin-login', 8, 900);
        $password = (string) ($body['password'] ?? '');
        if ($password === '' || strlen($password) > 256) {
            rovas_error('Invalid credentials', 403);
        }
        $result = rovas_admin_login($password);
        if (!$result['ok']) {
            rovas_error((string) $result['error'], (int) $result['status']);
        }
        rovas_json_response(['success' => true, 'csrf' => $result['csrf']]);
    }

    if ($action === 'setup') {
        rovas_rate_limit('admin-setup', 5, 900);
        $result = rovas_setup_admin(
            (string) ($body['setup_key'] ?? ''),
            (string) ($body['password'] ?? '')
        );
        if (!$result['ok']) {
            rovas_error((string) $result['error'], (int) $result['status']);
        }
        rovas_json_response(['success' => true, 'csrf' => $result['csrf']], 201);
    }

    rovas_require_admin();
    rovas_require_csrf();
    rovas_rate_limit('admin-write', 60, 60);

    $games = rovas_read_games();
    if ($action === 'logout') {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'], '', (bool) $params['secure'], (bool) $params['httponly']);
        }
        session_destroy();
        rovas_json_response(['success' => true]);
    }

    if ($action === 'add') {
        $name = trim((string) ($body['name'] ?? ''));
        $slug = rovas_safe_slug((string) ($body['slug'] ?? ''));
        if ($name === '' || strlen($name) > 120 || !rovas_valid_slug($slug)) {
            rovas_error('Valid name and slug are required', 400);
        }
        foreach ($games as $game) {
            if ((string) ($game['slug'] ?? '') === $slug) {
                rovas_error('Slug already exists', 409);
            }
        }

        $html = (string) ($body['game_html'] ?? '');
        if ($html !== '') {
            rovas_save_game_html($slug, $html);
        }
        $game = [
            'id' => random_int(1_000_000_000_000, PHP_INT_MAX),
            'slug' => $slug,
            'name' => $name,
            'image_url' => rovas_normalize_image_url((string) ($body['image_url'] ?? '')),
            'active' => true,
            'sort_order' => count($games),
        ];
        $games[] = $game;
        rovas_write_games($games);
        rovas_json_response(['success' => true, 'game' => $game], 201);
    }

    $id = filter_var($body['game_id'] ?? null, FILTER_VALIDATE_INT);
    if ($id === false || $id === null || $id < 1) {
        rovas_error('Valid game_id is required', 400);
    }
    $index = rovas_find_game_index($games, (int) $id);
    if ($index < 0) {
        rovas_error('Game not found', 404);
    }

    if ($action === 'edit') {
        if (array_key_exists('name', $body)) {
            $name = trim((string) $body['name']);
            if ($name === '' || strlen($name) > 120) {
                rovas_error('Valid name is required', 400);
            }
            $games[$index]['name'] = $name;
        }
        if (array_key_exists('image_url', $body)) {
            $games[$index]['image_url'] = rovas_normalize_image_url((string) $body['image_url']);
        }
        if (array_key_exists('sort_order', $body)) {
            $sortOrder = filter_var($body['sort_order'], FILTER_VALIDATE_INT);
            if ($sortOrder === false || $sortOrder < 0 || $sortOrder > 100000) {
                rovas_error('Invalid sort order', 400);
            }
            $games[$index]['sort_order'] = (int) $sortOrder;
        }
        if (array_key_exists('active', $body)) {
            $games[$index]['active'] = filter_var($body['active'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($games[$index]['active'] === null) {
                rovas_error('Invalid active value', 400);
            }
        }
        if (array_key_exists('game_html', $body) && (string) $body['game_html'] !== '') {
            rovas_save_game_html((string) $games[$index]['slug'], (string) $body['game_html']);
        }
        rovas_write_games($games);
        rovas_json_response(['success' => true]);
    }

    if ($action === 'delete') {
        $slug = (string) ($games[$index]['slug'] ?? '');
        array_splice($games, $index, 1);
        foreach ($games as $position => &$game) {
            $game['sort_order'] = $position;
        }
        unset($game);
        rovas_write_games($games);
        if ($slug !== '') {
            rovas_delete_game_html($slug);
        }
        rovas_json_response(['success' => true]);
    }

    if ($action === 'reorder') {
        $ids = $body['ids'] ?? null;
        if (!is_array($ids) || count($ids) > 1000) {
            rovas_error('ids is required', 400);
        }
        $positions = [];
        foreach ($ids as $position => $itemId) {
            $validId = filter_var($itemId, FILTER_VALIDATE_INT);
            if ($validId !== false && $validId !== null) {
                $positions[(int) $validId] = $position;
            }
        }
        foreach ($games as &$game) {
            $gameId = (int) ($game['id'] ?? 0);
            if (array_key_exists($gameId, $positions)) {
                $game['sort_order'] = (int) $positions[$gameId];
            }
        }
        unset($game);
        rovas_write_games($games);
        rovas_json_response(['success' => true]);
    }

    rovas_error('Unknown action', 400);
}

function rovas_handle_game_page(): never
{
    $slug = rovas_safe_slug((string) ($_GET['slug'] ?? ''));
    if (!rovas_valid_slug($slug)) {
        http_response_code(404);
        exit('Not found');
    }

    $game = null;
    foreach (rovas_read_games() as $candidate) {
        if ((string) ($candidate['slug'] ?? '') === $slug) {
            $game = $candidate;
            break;
        }
    }
    if ($game === null || ($game['active'] ?? true) === false) {
        http_response_code(404);
        exit('Not found');
    }

    $path = rovas_game_html_path($slug);
    if (!is_file($path)) {
        http_response_code(404);
        exit('Not found');
    }
    $html = (string) file_get_contents($path);
    $fixer = '<script>(function(){function fix(){document.querySelectorAll("[onclick]").forEach(function(el){var t=(el.textContent||"").toLowerCase();if(/exit|quitter|retour|back|close|menu/.test(t)){el.setAttribute("onclick","window.location.href=\\"/\\"");}})}fix();if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",fix)}setTimeout(fix,500);setTimeout(fix,1500)})();</script>';
    $html = preg_replace('/<\/body>/i', $fixer . "\n</body>", $html, 1) ?? ($html . $fixer);
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Content-Security-Policy: default-src \'self\' https: data: blob:; base-uri \'none\'; object-src \'none\'; frame-ancestors \'self\'; img-src \'self\' https: data: blob:; style-src \'self\' \'unsafe-inline\' https://fonts.googleapis.com; font-src \'self\' https://fonts.gstatic.com; script-src \'self\' \'unsafe-inline\' \'unsafe-eval\' https:; connect-src \'self\' https:; form-action \'self\'');
    echo $html;
    exit;
}

function rovas_handle_image(): never
{
    $file = (string) ($_GET['file'] ?? '');
    $path = rovas_image_path($file);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($path);
    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];
    if (!is_string($mime) || !array_key_exists($mime, $allowed)) {
        rovas_error('Unsupported image', 415);
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . (string) filesize($path));
    header('Cache-Control: public, max-age=3600, immutable');
    header('Content-Disposition: inline; filename="' . basename($path) . '"');
    readfile($path);
    exit;
}

function rovas_handle_upload(string $method): never
{
    if ($method !== 'POST') {
        rovas_error('Method not allowed', 405);
    }
    rovas_require_admin();
    rovas_require_csrf();
    rovas_rate_limit('admin-upload', 20, 300);

    if (!isset($_FILES['image']) || !is_array($_FILES['image'])) {
        rovas_error('Image is required', 400);
    }
    $file = $_FILES['image'];
    if ((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        rovas_error('Upload failed', 400);
    }
    if ((int) ($file['size'] ?? 0) < 1 || (int) $file['size'] > ROVAS_MAX_IMAGE_BYTES) {
        rovas_error('Image too large (max 2 MB)', 413);
    }
    $tmp = (string) ($file['tmp_name'] ?? '');
    if (!is_uploaded_file($tmp)) {
        rovas_error('Invalid upload', 400);
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $extensions = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];
    if (!is_string($mime) || !isset($extensions[$mime]) || @getimagesize($tmp) === false) {
        rovas_error('Unsupported image type', 415);
    }
    $original = pathinfo((string) ($file['name'] ?? 'image'), PATHINFO_FILENAME);
    $base = rovas_safe_slug(substr($original, 0, 40));
    $base = $base !== '' ? $base : 'image';
    $name = $base . '-' . bin2hex(random_bytes(8)) . '.' . $extensions[$mime];
    $destination = ROVAS_IMAGES_DIR . DIRECTORY_SEPARATOR . $name;
    if (!move_uploaded_file($tmp, $destination)) {
        rovas_error('Unable to save image', 500);
    }
    @chmod($destination, 0640);
    rovas_json_response([
        'success' => true,
        'url' => '/api/serve-image?file=' . rawurlencode($name),
        'filename' => $name,
        'size' => (int) $file['size'],
    ]);
}