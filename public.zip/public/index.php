<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/src/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
<title>ROVAS · Predictions</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap');

*{margin:0;padding:0;box-sizing:border-box}
html,body{touch-action:manipulation!important;overscroll-behavior:none}

:root{
  --rv-bg:#fff5f8;
  --rv-bg-card:#ffffff;
  --rv-primary:#e8388f;
  --rv-primary-dark:#c42078;
  --rv-primary-light:#f060a8;
  --rv-primary-pale:#f8c0d8;
  --rv-primary-ultra-pale:#fce8f0;
  --rv-accent:#f04890;
  --rv-accent-soft:rgba(240,72,144,0.12);
  --rv-accent-medium:rgba(240,72,144,0.25);
  --rv-text:#2d0a1e;
  --rv-text-secondary:#6b3a52;
  --rv-text-muted:#9b6880;
  --rv-text-light:#c49aaa;
  --rv-border:rgba(240,72,144,0.15);
  --rv-border-strong:rgba(240,72,144,0.35);
  --rv-shadow:rgba(200,40,120,0.08);
  --rv-shadow-strong:rgba(200,40,120,0.18);
}

body{
  font-family:'Poppins',-apple-system,BlinkMacSystemFont,sans-serif;
  background:var(--rv-bg);
  color:var(--rv-text);
  min-height:100vh;
  overflow-x:hidden;
}

/* Animated BG */
body::before{
  content:'';position:fixed;inset:0;
  background:
    radial-gradient(ellipse 500px 400px at 15% 5%,rgba(240,72,144,0.08) 0%,transparent 70%),
    radial-gradient(ellipse 400px 400px at 85% 80%,rgba(248,192,216,0.12) 0%,transparent 70%),
    radial-gradient(ellipse 350px 250px at 50% 50%,rgba(252,232,240,0.15) 0%,transparent 70%);
  animation:rv-bgFloat 20s ease-in-out infinite alternate;
  pointer-events:none;z-index:0;
}
body::after{
  content:'';position:fixed;inset:0;
  background:
    radial-gradient(ellipse 300px 200px at 70% 20%,rgba(240,96,168,0.06) 0%,transparent 70%),
    radial-gradient(ellipse 250px 250px at 20% 70%,rgba(232,56,143,0.05) 0%,transparent 70%);
  animation:rv-bgFloat2 28s ease-in-out infinite alternate;
  pointer-events:none;z-index:0;
}
@keyframes rv-bgFloat{0%{transform:translate(0,0) scale(1)}100%{transform:translate(15px,-10px) scale(1.05)}}
@keyframes rv-bgFloat2{0%{transform:translate(0,0) scale(1)}100%{transform:translate(-10px,15px) scale(1.03)}}

/* HEADER */
.dvys-header{
  position:sticky;top:0;z-index:100;
  backdrop-filter:blur(30px) saturate(180%);
  -webkit-backdrop-filter:blur(30px) saturate(180%);
  background:rgba(255,255,255,0.82);
  border-bottom:1px solid var(--rv-border);
  padding:12px 18px;
  display:flex;align-items:center;justify-content:space-between;
  animation:dvys-slideDown 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
  box-shadow:0 2px 20px var(--rv-shadow);
}
@keyframes dvys-slideDown{from{opacity:0;transform:translateY(-100%)}to{opacity:1;transform:translateY(0)}}

.dvys-header-left{display:flex;align-items:center;gap:10px}
.dvys-logo-icon{
  width:36px;height:36px;border-radius:10px;
  background:linear-gradient(135deg,var(--rv-primary-dark),var(--rv-primary),var(--rv-primary-light));
  display:flex;align-items:center;justify-content:center;
  box-shadow:0 2px 10px var(--rv-shadow-strong);
  color:#fff;font-weight:900;font-size:0.85rem;letter-spacing:1px;
}
.dvys-header-brand{display:flex;flex-direction:column}
.dvys-brand-name{
  font-size:1.15rem;font-weight:900;
  background:linear-gradient(135deg,var(--rv-primary-dark) 0%,var(--rv-primary) 50%,var(--rv-primary-light) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  letter-spacing:2.5px;line-height:1.2;
}
.dvys-brand-sub{font-size:0.55rem;color:var(--rv-text-muted);font-weight:600;letter-spacing:2.5px;text-transform:uppercase}

/* HERO */
.dvys-hero{
  text-align:center;padding:30px 20px 20px;
  position:relative;z-index:1;
  animation:dvys-fadeInUp 0.7s cubic-bezier(0.34,1.56,0.64,1) 0.1s both;
}
.dvys-hero h1{
  font-size:1.85rem;font-weight:900;
  background:linear-gradient(135deg,var(--rv-primary-dark) 0%,var(--rv-primary) 40%,var(--rv-primary-light) 100%);
  -webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;
  margin-bottom:6px;
}
.dvys-hero p{font-size:0.82rem;color:var(--rv-text-secondary);font-weight:500}
@keyframes dvys-fadeInUp{from{opacity:0;transform:translateY(20px)}to{opacity:1;transform:translateY(0)}}

/* LOADING */
.dvys-loading{
  position:relative;z-index:1;text-align:center;padding:50px 20px;
}
.dvys-loading-spinner{
  width:42px;height:42px;
  border:3px solid var(--rv-border);
  border-top-color:var(--rv-primary);
  border-right-color:var(--rv-primary-light);
  border-radius:50%;
  animation:spin 0.7s linear infinite;
  margin:0 auto 14px;
}
@keyframes spin{to{transform:rotate(360deg)}}

/* SEARCH */
.dvys-search-wrap{
  position:relative;z-index:1;max-width:500px;margin:0 auto;
  padding:0 16px 16px;display:none;
  animation:dvys-fadeInUp 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
}
.dvys-search-wrap.show{display:block}
.dvys-search-input{
  width:100%;padding:12px 16px 12px 44px;
  border:1.5px solid var(--rv-border);border-radius:14px;
  background:rgba(255,255,255,0.65);
  backdrop-filter:blur(20px) saturate(140%);
  font-family:'Poppins',sans-serif;font-size:0.84rem;font-weight:500;
  color:var(--rv-text);outline:none;transition:all 0.3s;
  box-shadow:0 2px 12px var(--rv-shadow);
}
.dvys-search-input::placeholder{color:var(--rv-text-muted)}
.dvys-search-input:focus{
  border-color:var(--rv-primary);
  box-shadow:0 0 0 3px rgba(232,56,143,0.12),0 4px 16px var(--rv-shadow-strong);
}
.dvys-search-icon{
  position:absolute;left:30px;top:50%;transform:translateY(-50%);
  pointer-events:none;color:var(--rv-text-muted);
}
.dvys-search-icon svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.dvys-search-clear{
  position:absolute;right:30px;top:50%;transform:translateY(-50%);
  width:22px;height:22px;border-radius:50%;
  background:var(--rv-accent-soft);border:1px solid var(--rv-border);
  color:var(--rv-text-muted);font-size:0.7rem;font-weight:700;
  display:none;align-items:center;justify-content:center;
  cursor:pointer;
}
.dvys-search-clear.show{display:flex}

/* GAME GRID */
.dvys-grid{
  position:relative;z-index:1;
  display:grid;grid-template-columns:repeat(2,1fr);
  gap:14px;padding:0 16px 100px;
  max-width:500px;margin:0 auto;
}

/* CARDS */
.dvys-card{
  display:block;border-radius:18px;overflow:hidden;
  background:rgba(255,255,255,0.55);
  border:1.5px solid rgba(240,72,144,0.18);
  backdrop-filter:blur(20px) saturate(140%);
  text-decoration:none;color:var(--rv-text);
  transition:all 0.35s cubic-bezier(0.34,1.56,0.64,1);
  animation:dvys-fadeInUp 0.6s cubic-bezier(0.34,1.56,0.64,1) both;
  box-shadow:0 1px 2px rgba(200,40,120,0.06),0 4px 8px rgba(200,40,120,0.08),0 12px 24px rgba(200,40,120,0.10);
  cursor:pointer;
}
.dvys-card:active{transform:scale(0.97)}
.dvys-card:hover{
  transform:translateY(-6px) scale(1.02);
  border-color:rgba(240,72,144,0.30);
  box-shadow:0 2px 4px rgba(200,40,120,0.08),0 8px 16px rgba(200,40,120,0.12),0 20px 40px rgba(200,40,120,0.14);
}

.dvys-card-img{
  width:100%;overflow:hidden;position:relative;
  background:linear-gradient(135deg,var(--rv-primary-ultra-pale),var(--rv-bg));
  aspect-ratio:1/1;
}
.dvys-card-img img{width:100%;height:100%;display:block;object-fit:cover;transition:transform 0.4s}
.dvys-card:hover .dvys-card-img img{transform:scale(1.05)}

.dvys-card-body{padding:10px 12px;display:flex;justify-content:space-between;align-items:center}
.dvys-card-name{font-size:0.78rem;font-weight:700;color:var(--rv-text)}
.dvys-card-badge{
  font-size:0.56rem;font-weight:700;padding:4px 10px;border-radius:20px;
  background:linear-gradient(135deg,var(--rv-primary-dark),var(--rv-primary),var(--rv-primary-light));
  background-size:200% 200%;animation:badgeShimmer 2.5s ease-in-out infinite;
  color:#fff;letter-spacing:0.5px;
  box-shadow:0 2px 8px rgba(240,72,144,0.25);
}
@keyframes badgeShimmer{0%,100%{background-position:0% 50%}50%{background-position:100% 50%}}

/* NO RESULTS */
.dvys-no-results{
  grid-column:1/-1;text-align:center;padding:40px 20px;
  color:var(--rv-text-muted);font-size:0.85rem;display:none;
}
.dvys-no-results.show{display:block}

/* FOOTER */
.dvys-footer{
  text-align:center;padding:20px;font-size:0.6rem;
  color:var(--rv-text-light);letter-spacing:2px;text-transform:uppercase;
  position:relative;z-index:1;
}

/* FIXED BADGE */
.dvys-fixed-badge{
  position:fixed;bottom:14px;right:14px;
  padding:6px 14px;border-radius:20px;
  backdrop-filter:blur(16px);
  background:rgba(255,255,255,0.75);border:1.5px solid var(--rv-border-strong);
  font-size:0.56rem;font-weight:800;color:var(--rv-primary);
  letter-spacing:2px;z-index:100;
  animation:dvys-badgeFloat 3s ease-in-out infinite;
  pointer-events:none;box-shadow:0 2px 12px var(--rv-shadow);
}
@keyframes dvys-badgeFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}

/* INFO MODAL */
.dvys-modal-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(45,10,30,0.3);backdrop-filter:blur(8px);
  z-index:200;justify-content:center;align-items:center;
}
.dvys-modal-overlay.show{display:flex}
.dvys-modal{
  background:rgba(255,255,255,0.95);
  border:1px solid var(--rv-border);border-radius:24px;
  padding:24px 22px;max-width:380px;width:92%;
  animation:dvys-modalPop 0.5s cubic-bezier(0.34,1.56,0.64,1) both;
  box-shadow:0 20px 60px var(--rv-shadow-strong);
  max-height:90vh;overflow-y:auto;
}
@keyframes dvys-modalPop{from{transform:scale(0.85);opacity:0}to{transform:scale(1);opacity:1}}
.dvys-modal h2{font-size:1.1rem;font-weight:800;color:var(--rv-primary);margin-bottom:14px;text-align:center}
.dvys-modal p{font-size:0.8rem;color:var(--rv-text-secondary);line-height:1.6;margin-bottom:14px}
.dvys-modal-close{
  width:100%;padding:12px;border:1.5px solid var(--rv-border-strong);border-radius:14px;
  background:var(--rv-accent-soft);color:var(--rv-primary);
  font-family:'Poppins',sans-serif;font-size:0.85rem;font-weight:700;cursor:pointer;
}
.dvys-promo{
  display:inline-block;padding:10px 24px;
  background:linear-gradient(135deg,var(--rv-accent-soft),rgba(255,255,255,0.6));
  border:2.5px dashed var(--rv-border-strong);border-radius:12px;
  font-size:1.3rem;font-weight:900;color:var(--rv-primary);letter-spacing:4px;margin-bottom:6px;
}
.dvys-bonus{font-size:0.95rem;font-weight:800;color:#10b981;margin-bottom:10px}

@media(max-width:400px){
  .dvys-hero h1{font-size:1.5rem}
  .dvys-grid{gap:10px;padding:0 12px 80px}
}
@media(prefers-reduced-motion:reduce){
  *,*::before,*::after{animation-duration:0.01ms!important;transition-duration:0.01ms!important}
}
</style>
</head>
<body>

<!-- HEADER -->
<div class="dvys-header">
  <div class="dvys-header-left">
    <div class="dvys-logo-icon">R</div>
    <div class="dvys-header-brand">
      <span class="dvys-brand-name">ROVAS</span>
      <span class="dvys-brand-sub">1win Prediction</span>
    </div>
  </div>
  <div class="dvys-header-right">
    <div class="dvys-info-btn" onclick="toggleModal()" style="width:34px;height:34px;border-radius:10px;background:var(--rv-accent-soft);border:1.5px solid var(--rv-border-strong);color:var(--rv-primary);cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;padding:8px 6px;transition:all 0.3s">
      <span style="display:block;width:18px;height:2px;background:var(--rv-primary);border-radius:1px"></span>
      <span style="display:block;width:18px;height:2px;background:var(--rv-primary);border-radius:1px"></span>
      <span style="display:block;width:18px;height:2px;background:var(--rv-primary);border-radius:1px"></span>
    </div>
  </div>
</div>

<!-- HERO -->
<div class="dvys-hero">
  <h1>ROVAS Predictions</h1>
  <p id="heroSubtitle">Chargement...</p>
</div>

<!-- SEARCH -->
<div class="dvys-search-wrap" id="searchWrap">
  <span class="dvys-search-icon"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></span>
  <input type="text" class="dvys-search-input" id="searchInput" placeholder="Rechercher un jeu..." oninput="onSearch(this.value)">
  <span class="dvys-search-clear" id="searchClear" onclick="clearSearch()">x</span>
</div>

<!-- LOADING -->
<div class="dvys-loading" id="loadingGames">
  <div class="dvys-loading-spinner"></div>
  <div style="font-size:0.82rem;color:var(--rv-text-muted)">Chargement des jeux...</div>
</div>

<!-- GAME GRID -->
<div class="dvys-grid" id="gamesGrid" style="display:none"></div>

<!-- NO RESULTS -->
<div class="dvys-no-results" id="noResults">
  <span>?</span>
  Aucun jeu trouve
</div>

<!-- FOOTER -->
<div class="dvys-footer">All rights reserved ROVAS</div>

<!-- FIXED BADGE -->
<div class="dvys-fixed-badge">ROVAS</div>

<!-- INFO MODAL -->
<div class="dvys-modal-overlay" id="infoModal" onclick="if(event.target===this)toggleModal()">
  <div class="dvys-modal">
    <h2>Informations</h2>
    <p>ROVAS IA est une plateforme de predictions de jeux de casino en temps reel grace a des algorithmes intelligents qui analysent les donnees avant et pendant chaque partie.</p>
    <p>Utilisez le code promo ci-dessous pour beneficier d'un bonus de 500% sur votre premier depot.</p>
    <div style="text-align:center">
      <div class="dvys-promo">ROVAS</div>
      <div class="dvys-bonus">+500% BONUS</div>
    </div>
    <button class="dvys-modal-close" onclick="toggleModal()">Fermer</button>
  </div>
</div>

<script>
// ─── Telegram WebApp ───
try {
  var tg = window.Telegram && window.Telegram.WebApp;
  if (tg) {
    tg.ready();
    tg.expand();
    if (tg.setHeaderColor) tg.setHeaderColor('#ffffff');
    if (tg.setBackgroundColor) tg.setBackgroundColor('#fff5f8');
  }
} catch(e) {}

// ─── Globals ───
var allGames = [];
var BASE_URL = window.location.origin;

// ─── Load Games ───
async function loadGames() {
  try {
    var res = await fetch('/api/games');
    var data = await res.json();
    if (data.success && data.games) {
      allGames = data.games;
      renderGames(allGames);
    } else {
      showError();
    }
  } catch(e) {
    showError();
  }
}

function renderGames(games) {
  var grid = document.getElementById('gamesGrid');
  var loading = document.getElementById('loadingGames');
  var searchWrap = document.getElementById('searchWrap');
  var subtitle = document.getElementById('heroSubtitle');

  loading.style.display = 'none';

  var count = games.length;
  subtitle.textContent = count + ' jeu' + (count > 1 ? 'x' : '') + ' disponible' + (count > 1 ? 's' : '');

  if (count === 0) {
    grid.style.display = 'none';
    searchWrap.style.display = 'none';
    return;
  }

  grid.style.display = 'grid';
  searchWrap.style.display = 'block';

  var html = '';
  for (var i = 0; i < games.length; i++) {
    var g = games[i];
    var delay = Math.min(i * 0.08, 0.6);
    var imgUrl = g.image_url || 'data:image/svg+xml,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><rect fill="#fce8f0" width="200" height="200"/><text x="100" y="110" text-anchor="middle" font-family="sans-serif" font-size="14" font-weight="700" fill="#e8388f">' + (g.name || 'Game') + '</text></svg>');

    html += '<a class="dvys-card" href="/api/game-page?slug=' + encodeURIComponent(g.slug) + '" style="animation-delay:' + delay + 's">';
    html += '  <div class="dvys-card-img">';
    html += '    <img src="' + escapeHtml(imgUrl) + '" alt="' + escapeHtml(g.name) + '" loading="lazy" onerror="this.src=\'data:image/svg+xml,\' + encodeURIComponent(\'<svg xmlns=\\\'http://www.w3.org/2000/svg\\\' width=\\\'200\\\' height=\\\'200\\\'><rect fill=\\\'#fce8f0\\\' width=\\\'200\\\' height=\\\'200\\\'/><text x=\\\'100\\\' y=\\\'110\\\' text-anchor=\\\'middle\\\' font-family=\\\'sans-serif\\\' font-size=\\\'14\\\' font-weight=\\\'700\\\' fill=\\\'#e8388f\\\'>\' + encodeURIComponent(\'' + escapeHtml(g.name) + '\') + \'</text></svg>\')">';
    html += '  </div>';
    html += '  <div class="dvys-card-body">';
    html += '    <span class="dvys-card-name">' + escapeHtml(g.name) + '</span>';
    html += '    <span class="dvys-card-badge">JOUER</span>';
    html += '  </div>';
    html += '</a>';
  }
  grid.innerHTML = html;
}

function showError() {
  document.getElementById('loadingGames').innerHTML = '<div style="font-size:0.82rem;color:var(--rv-text-muted)">Erreur de chargement. Reessayez.</div><div style="margin-top:12px"><button onclick="loadGames()" style="padding:8px 20px;border-radius:12px;border:1.5px solid var(--rv-border-strong);background:var(--rv-accent-soft);color:var(--rv-primary);font-family:Poppins;font-weight:600;cursor:pointer">Reessayer</button></div>';
}

// ─── Search ───
function onSearch(query) {
  var clear = document.getElementById('searchClear');
  clear.classList.toggle('show', query.length > 0);

  if (!query) {
    renderGames(allGames);
    document.getElementById('noResults').classList.remove('show');
    return;
  }

  var q = query.toLowerCase();
  var filtered = allGames.filter(function(g) {
    return g.name.toLowerCase().indexOf(q) !== -1;
  });

  if (filtered.length > 0) {
    renderGames(filtered);
    document.getElementById('noResults').classList.remove('show');
  } else {
    document.getElementById('gamesGrid').innerHTML = '';
    document.getElementById('noResults').classList.add('show');
  }
}

function clearSearch() {
  document.getElementById('searchInput').value = '';
  document.getElementById('searchClear').classList.remove('show');
  document.getElementById('noResults').classList.remove('show');
  renderGames(allGames);
}

// ─── Modal ───
function toggleModal() {
  document.getElementById('infoModal').classList.toggle('show');
}

// ─── Utils ───
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Init ───
loadGames();
</script>
</body>
</html>
