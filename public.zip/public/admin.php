<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/src/bootstrap.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>ROVAS - Administration</title>
<style>
@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800;900&display=swap');

*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{touch-action:manipulation;overscroll-behavior:none}
input,textarea,button,select{font-size:16px!important}

:root{
  --bg:#f5f0f2;
  --card:rgba(255,255,255,0.85);
  --primary:#e8388f;
  --primary-dark:#c42078;
  --primary-light:#f060a8;
  --primary-pale:#fce8f0;
  --accent-soft:rgba(240,72,144,0.10);
  --accent-medium:rgba(240,72,144,0.22);
  --text:#2d0a1e;
  --text2:#6b3a52;
  --text3:#9b6880;
  --border:rgba(240,72,144,0.15);
  --border2:rgba(240,72,144,0.35);
  --shadow:rgba(200,40,120,0.08);
  --green:#10b981;
  --red:#ef4444;
  --radius:16px;
}

body{font-family:'Poppins',-apple-system,sans-serif;background:var(--bg);color:var(--text);min-height:100vh;line-height:1.5}

/* Login */
.login-screen{display:flex;align-items:center;justify-content:center;min-height:100vh;padding:24px;background:linear-gradient(135deg,#fce8f0 0%,#f5f0f2 50%,#fce8f0 100%)}
.login-card{background:rgba(255,255,255,0.92);backdrop-filter:blur(30px);border-radius:24px;padding:36px 28px;max-width:380px;width:100%;text-align:center;box-shadow:0 20px 60px var(--shadow);border:1px solid var(--border)}
.login-card .logo{font-size:2rem;font-weight:900;background:linear-gradient(135deg,var(--primary-dark),var(--primary-light));-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:4px;letter-spacing:3px}
.login-card .sub{font-size:0.75rem;color:var(--text3);font-weight:600;letter-spacing:2px;margin-bottom:28px}
.login-card input{width:100%;padding:14px 16px;border:1.5px solid var(--border);border-radius:12px;background:rgba(255,255,255,0.6);font-size:15px;font-weight:500;color:var(--text);text-align:center;outline:none;font-family:inherit;margin-bottom:14px;transition:all 0.3s}
.login-card input:focus{border-color:var(--primary);box-shadow:0 0 0 3px var(--accent-soft)}
.login-card button{width:100%;padding:14px;background:linear-gradient(135deg,var(--primary-dark),var(--primary));color:#fff;border:none;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;box-shadow:0 4px 16px rgba(240,72,144,0.3);transition:all 0.2s}
.login-card button:active{transform:scale(0.97)}
.login-error{color:var(--red);font-size:13px;margin-top:12px;display:none;font-weight:600}

/* Dashboard */
.dashboard{display:none;animation:fadeIn 0.4s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}

/* Header */
.header{background:rgba(255,255,255,0.82);backdrop-filter:blur(30px);-webkit-backdrop-filter:blur(30px);border-bottom:1px solid var(--border);padding:0 20px;height:56px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100}
.header-left{display:flex;align-items:center;gap:10px}
.header-icon{width:34px;height:34px;border-radius:10px;background:linear-gradient(135deg,var(--primary-dark),var(--primary-light));display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:0.8rem;letter-spacing:1px}
.header h1{font-size:1rem;font-weight:800;letter-spacing:-0.3px}
.header h1 small{font-size:0.65rem;color:var(--text3);font-weight:600;display:block;letter-spacing:0.5px}
.btn-logout{padding:6px 14px;background:rgba(239,68,68,0.1);border:none;border-radius:10px;color:var(--red);font-size:12px;font-weight:700;cursor:pointer;font-family:inherit}

/* Content */
.content{max-width:800px;margin:0 auto;padding:20px 16px 100px}

/* Glass Card */
.glass-card{background:var(--card);backdrop-filter:blur(16px);border-radius:var(--radius);padding:20px;box-shadow:0 2px 12px var(--shadow);border:1px solid var(--border);margin-bottom:16px}
.glass-card h3{font-size:1rem;font-weight:700;margin-bottom:16px;display:flex;align-items:center;gap:8px}

/* Form */
.form-group{margin-bottom:16px}
.form-group:last-child{margin-bottom:0}
.form-group label{display:block;font-size:12px;font-weight:700;color:var(--text2);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px}
.form-input{width:100%;padding:12px 14px;border:1.5px solid var(--border2);border-radius:12px;background:rgba(255,255,255,0.8);font-size:14px;font-weight:500;color:var(--text);outline:none;font-family:inherit;transition:all 0.25s}
.form-input:focus{border-color:var(--primary);box-shadow:0 0 0 3px var(--accent-soft)}
textarea.form-input{min-height:120px;resize:vertical;font-family:monospace;font-size:13px}

/* Or separator */
.or-sep{display:flex;align-items:center;gap:10px;margin:12px 0;color:var(--text3);font-size:12px;font-weight:600}
.or-sep::before,.or-sep::after{content:'';flex:1;height:1px;background:var(--border)}

/* Upload buttons */
.upload-zone{position:relative;border:2px dashed var(--border2);border-radius:12px;padding:20px;text-align:center;cursor:pointer;transition:all 0.25s;background:rgba(255,255,255,0.4)}
.upload-zone:hover,.upload-zone.dragover{border-color:var(--primary);background:var(--accent-soft)}
.upload-zone input[type="file"]{position:absolute;inset:0;opacity:0;cursor:pointer}
.upload-zone .upload-icon{font-size:1.8rem;margin-bottom:6px;display:block;color:var(--text3)}
.upload-zone .upload-text{font-size:13px;color:var(--text3);font-weight:500}
.upload-zone .upload-text strong{color:var(--primary);font-weight:700}
.upload-zone.uploading{pointer-events:none;opacity:0.6}

/* Upload progress */
.upload-progress{display:none;margin-top:8px}
.upload-progress.active{display:block}
.upload-bar{height:4px;background:var(--border);border-radius:2px;overflow:hidden}
.upload-bar .fill{height:100%;width:0%;background:linear-gradient(90deg,var(--primary-dark),var(--primary-light));border-radius:2px;transition:width 0.3s}
.upload-status{font-size:11px;color:var(--text3);margin-top:4px;font-weight:500}

/* Image preview */
.img-preview{display:none;margin-top:10px;position:relative;border-radius:12px;overflow:hidden;border:1.5px solid var(--border)}
.img-preview.active{display:block}
.img-preview img{width:100%;max-height:160px;object-fit:cover;display:block}
.img-preview .remove-img{position:absolute;top:6px;right:6px;width:26px;height:26px;border-radius:50%;background:rgba(0,0,0,0.6);color:#fff;border:none;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;font-weight:700}

/* Buttons */
.btn-primary{padding:12px 24px;background:linear-gradient(135deg,var(--primary-dark),var(--primary));color:#fff;border:none;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit;box-shadow:0 2px 10px rgba(240,72,144,0.3);transition:all 0.2s}
.btn-primary:active{transform:scale(0.97)}
.btn-danger{padding:10px 20px;background:var(--red);color:#fff;border:none;border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
.btn-secondary{padding:10px 20px;background:var(--bg);color:var(--text);border:1px solid var(--border2);border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;font-family:inherit}
.btn-sm{padding:7px 14px;font-size:12px;border-radius:10px}
.btn-outline{padding:10px 18px;background:transparent;border:1.5px solid var(--border2);border-radius:12px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;color:var(--text2);transition:all 0.2s;display:inline-flex;align-items:center;gap:6px}
.btn-outline:active{transform:scale(0.97)}
.btn-outline svg{width:16px;height:16px}

/* Game List */
.game-item{display:flex;align-items:center;gap:14px;padding:14px;border-bottom:1px solid var(--border);transition:background 0.2s;cursor:grab}
.game-item:last-child{border-bottom:none}
.game-item:hover{background:var(--accent-soft)}
.game-item img{width:52px;height:52px;border-radius:12px;object-fit:cover;background:var(--primary-pale);flex-shrink:0;border:1.5px solid var(--border)}
.game-item .game-info{flex:1;min-width:0}
.game-item .game-name{font-size:14px;font-weight:700}
.game-item .game-slug{font-size:11px;color:var(--text3);font-weight:500}
.game-item .game-actions{display:flex;gap:6px;flex-shrink:0}

/* Toggle */
.toggle{position:relative;width:44px;height:24px;cursor:pointer}
.toggle input{display:none}
.toggle .slider{position:absolute;inset:0;background:#d1d5db;border-radius:12px;transition:0.3s}
.toggle .slider::before{content:'';position:absolute;width:20px;height:20px;left:2px;top:2px;background:#fff;border-radius:50%;transition:0.3s}
.toggle input:checked+.slider{background:var(--primary)}
.toggle input:checked+.slider::before{transform:translateX(20px)}

/* Empty State */
.empty-state{text-align:center;padding:48px 20px;color:var(--text3)}
.empty-state .icon{font-size:3rem;margin-bottom:12px;display:block}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(45,10,30,0.4);backdrop-filter:blur(6px);z-index:200;justify-content:center;align-items:center;padding:20px}
.modal-overlay.show{display:flex}
.modal{background:rgba(255,255,255,0.96);border:1px solid var(--border);border-radius:20px;padding:24px;max-width:600px;width:100%;max-height:85vh;overflow-y:auto;animation:modalPop 0.4s cubic-bezier(0.34,1.56,0.64,1) both;box-shadow:0 20px 60px var(--shadow)}
@keyframes modalPop{from{transform:scale(0.9);opacity:0}to{transform:scale(1);opacity:1}}
.modal h2{font-size:1.1rem;font-weight:800;color:var(--primary);margin-bottom:18px}
.modal-actions{display:flex;gap:10px;margin-top:18px;justify-content:flex-end}

/* Toast */
.toast{position:fixed;top:20px;left:50%;transform:translateX(-50%) translateY(-80px);padding:12px 24px;border-radius:14px;font-size:13px;font-weight:600;z-index:300;transition:transform 0.4s cubic-bezier(0.34,1.56,0.64,1);box-shadow:0 8px 24px rgba(0,0,0,0.15)}
.toast.show{transform:translateX(-50%) translateY(0)}
.toast.success{background:#d1fae5;color:#065f46;border:1px solid #a7f3d0}
.toast.error{background:#fee2e2;color:#991b1b;border:1px solid #fecaca}

/* Responsive */
@media(max-width:500px){
  .content{padding:14px 10px 80px}
  .glass-card{padding:16px}
  .game-item{padding:10px;gap:10px}
  .game-item img{width:42px;height:42px}
}
</style>
</head>
<body>

<!-- LOGIN -->
<div class="login-screen" id="loginScreen">
  <div class="login-card">
    <div class="logo">ROVAS</div>
    <div class="sub">ADMINISTRATION</div>
    <input type="password" id="loginPassword" placeholder="Mot de passe" onkeydown="if(event.key==='Enter')doLogin()">
    <button onclick="doLogin()">Connexion</button>
    <div class="login-error" id="loginError">Mot de passe incorrect</div>
      <button class="btn-secondary" id="showSetupButton" onclick="showSetup()" style="display:none;margin-top:10px;width:100%">Premiere configuration</button>
  </div>
</div>

  <div class="login-screen" id="setupScreen" style="display:none">
    <div class="login-card">
      <div class="logo">ROVAS</div>
      <div class="sub">CONFIGURATION SECURISEE</div>
      <p style="font-size:13px;color:var(--text2);margin-bottom:16px">Creez le mot de passe administrateur depuis votre navigateur. Le code de configuration doit etre defini dans les variables protegees de votre hebergement.</p>
      <input type="password" id="setupKey" placeholder="Code de configuration">
      <input type="password" id="setupPassword" placeholder="Nouveau mot de passe (16 caracteres min.)">
      <input type="password" id="setupPasswordConfirm" placeholder="Confirmer le mot de passe">
      <button onclick="doSetup()">Configurer</button>
      <button class="btn-secondary" onclick="showLogin()" style="margin-top:10px;width:100%">Retour</button>
      <div class="login-error" id="setupError"></div>
    </div>
  </div>

<!-- DASHBOARD -->
<div class="dashboard" id="dashboard">
  <!-- Header -->
  <div class="header">
    <div class="header-left">
      <div class="header-icon">R</div>
      <h1>ROVAS Admin<small>Gestion des jeux</small></h1>
    </div>
    <button class="btn-logout" onclick="doLogout()">Deconnexion</button>
  </div>

  <!-- Content -->
  <div class="content">
    <!-- Add Game -->
    <div class="glass-card">
      <h3>Ajouter un jeu</h3>
      <div class="form-group">
        <label>Nom du jeu</label>
        <input type="text" class="form-input" id="addName" placeholder="Ex: Aviator">
      </div>
      <div class="form-group">
        <label>Slug (identifiant URL)</label>
        <input type="text" class="form-input" id="addSlug" placeholder="Ex: aviator">
      </div>

      <!-- Image Section -->
      <div class="form-group">
        <label>Image du jeu</label>
        <input type="url" class="form-input" id="addImage" placeholder="https://example.com/game.png">
        <div class="or-sep">ou</div>
        <div class="upload-zone" id="addImgZone">
          <input type="file" accept="image/*" onchange="handleImageUpload(this, 'add')">
          <span class="upload-icon">&#128247;</span>
          <span class="upload-text"><strong>Importer une image</strong><br>JPG, PNG, GIF ou WebP (max 2 Mo)</span>
        </div>
        <div class="upload-progress" id="addImgProgress">
          <div class="upload-bar"><div class="fill" id="addImgFill"></div></div>
          <div class="upload-status" id="addImgStatus"></div>
        </div>
        <div class="img-preview" id="addImgPreview">
          <img src="" alt="Apercu">
          <button class="remove-img" onclick="removeImage('add')">&times;</button>
        </div>
      </div>

      <!-- HTML Section -->
      <div class="form-group">
        <label>Code HTML du jeu (optionnel)</label>
        <textarea class="form-input" id="addHtml" placeholder="Collez ici le code HTML complet de la page du jeu..."></textarea>
        <div style="margin-top:8px">
          <label class="btn-outline" for="addHtmlFile">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
            Importer un fichier HTML
          </label>
          <input type="file" id="addHtmlFile" accept=".html,.htm" style="display:none" onchange="handleHtmlImport(this, 'add')">
        </div>
      </div>
      <button class="btn-primary" onclick="addGame()">Ajouter</button>
    </div>

    <!-- Games List -->
    <div class="glass-card">
      <h3>Jeux (<span id="gameCount">0</span>)</h3>
      <div id="gamesList"></div>
    </div>
  </div>
</div>

<!-- EDIT MODAL -->
<div class="modal-overlay" id="editModal" onclick="if(event.target===this)closeEditModal()">
  <div class="modal">
    <h2>Modifier le jeu</h2>
    <div class="form-group">
      <label>Nom du jeu</label>
      <input type="text" class="form-input" id="editName">
    </div>

    <!-- Edit Image Section -->
    <div class="form-group">
      <label>Image du jeu</label>
      <input type="url" class="form-input" id="editImage" placeholder="https://example.com/game.png">
      <div class="or-sep">ou</div>
      <div class="upload-zone" id="editImgZone">
        <input type="file" accept="image/*" onchange="handleImageUpload(this, 'edit')">
        <span class="upload-icon">&#128247;</span>
       <span class="upload-text"><strong>Importer une image</strong><br>JPG, PNG, GIF ou WebP (max 2 Mo)</span>
      </div>
      <div class="upload-progress" id="editImgProgress">
        <div class="upload-bar"><div class="fill" id="editImgFill"></div></div>
        <div class="upload-status" id="editImgStatus"></div>
      </div>
      <div class="img-preview" id="editImgPreview">
        <img src="" alt="Apercu">
        <button class="remove-img" onclick="removeImage('edit')">&times;</button>
      </div>
    </div>

    <!-- Edit HTML Section -->
    <div class="form-group">
      <label>Code HTML du jeu</label>
      <textarea class="form-input" id="editHtml" rows="12"></textarea>
      <div style="margin-top:8px">
        <label class="btn-outline" for="editHtmlFile">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
          Importer un fichier HTML
        </label>
        <input type="file" id="editHtmlFile" accept=".html,.htm" style="display:none" onchange="handleHtmlImport(this, 'edit')">
      </div>
    </div>
    <input type="hidden" id="editId">
    <div class="modal-actions">
      <button class="btn-secondary" onclick="closeEditModal()">Annuler</button>
      <button class="btn-primary" onclick="saveGame()">Enregistrer</button>
    </div>
  </div>
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<script>
 var CSRF = '';
var allGames = [];
var currentSha = null;

// ─── Auth ───
function doLogin() {
  var pw = document.getElementById('loginPassword').value;
  if (!pw) return;
  fetch('/api/games', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'login', password: pw })
  })
    .then(function(r) { return r.json().then(function(data) { return { ok: r.ok, data: data }; }); })
    .then(function(data) {
      if (data.ok && data.data.success) {
        CSRF = data.data.csrf || '';
        loadGames();
      } else {
        showError('loginError', data.data.error || 'Mot de passe incorrect');
      }
    })
    .catch(function() {
      showError('loginError', 'Erreur reseau');
    });
}

function doSetup() {
  var key = document.getElementById('setupKey').value;
  var password = document.getElementById('setupPassword').value;
  var confirmPassword = document.getElementById('setupPasswordConfirm').value;
  if (!key || !password) { showError('setupError', 'Tous les champs sont requis'); return; }
  if (password.length < 16) { showError('setupError', 'Le mot de passe doit contenir au moins 16 caracteres'); return; }
  if (password !== confirmPassword) { showError('setupError', 'Les mots de passe ne correspondent pas'); return; }
  fetch('/api/games', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'setup', setup_key: key, password: password })
  })
    .then(function(r) { return r.json().then(function(data) { return { ok: r.ok, data: data }; }); })
    .then(function(result) {
      if (result.ok && result.data.success) {
        CSRF = result.data.csrf || '';
        showToast('Configuration terminee', 'success');
        loadGames();
      } else {
        showError('setupError', result.data.error || 'Configuration impossible');
      }
    })
    .catch(function() { showError('setupError', 'Erreur reseau'); });
}

function showSetup() {
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('setupScreen').style.display = 'flex';
  document.getElementById('setupError').style.display = 'none';
}

function showLogin() {
  document.getElementById('setupScreen').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
}

function showError(id, message) {
  var el = document.getElementById(id);
  el.textContent = message;
  el.style.display = 'block';
}

function checkSetupStatus() {
  fetch('/api/games?status=1')
    .then(function(r) { return r.json(); })
    .then(function(data) {
      var button = document.getElementById('showSetupButton');
      if (!data.configured && data.setup_available) {
        button.style.display = 'block';
      }
      if (!data.configured && !data.setup_available) {
        showError('loginError', 'Definissez ROVAS_SETUP_KEY dans votre hebergement');
      }
    })
    .catch(function() {});
}

function doLogout() {
  fetch('/api/games', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
    body: JSON.stringify({ action: 'logout' })
  }).catch(function() {});
  CSRF = '';
  document.getElementById('dashboard').style.display = 'none';
  document.getElementById('loginScreen').style.display = 'flex';
  document.getElementById('setupScreen').style.display = 'none';
  document.getElementById('loginPassword').value = '';
}

function showDashboard(data) {
  document.getElementById('loginScreen').style.display = 'none';
  document.getElementById('dashboard').style.display = 'block';
  allGames = data.games || [];
  currentSha = data.sha || null;
  renderGamesList();
}

// ─── Load Games ───
function loadGames() {
  fetch('/api/games?admin=1')
    .then(function(r) { return r.json().then(function(data) { return { ok: r.ok, data: data }; }); })
    .then(function(data) {
      if (data.ok && data.data.success) {
        CSRF = data.data.csrf || CSRF;
        allGames = data.data.games || [];
        renderGamesList();
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('setupScreen').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
      } else {
        doLogout();
      }
    }).catch(function() { doLogout(); });
}

// ─── Render Games List ───
function renderGamesList() {
  var list = document.getElementById('gamesList');
  document.getElementById('gameCount').textContent = allGames.length;

  if (allGames.length === 0) {
    list.innerHTML = '<div class="empty-state"><span class="icon">?</span><p>Aucun jeu. Ajoutez votre premier jeu ci-dessus.</p></div>';
    return;
  }

  var html = '';
  for (var i = 0; i < allGames.length; i++) {
    var g = allGames[i];
    var imgSrc = g.image_url || '';
    html += '<div class="game-item" data-id="' + g.id + '">';
    if (imgSrc) {
      html += '<img src="' + esc(imgSrc) + '" alt="" onerror="this.style.display=\'none\'">';
    } else {
      html += '<div style="width:52px;height:52px;border-radius:12px;background:var(--primary-pale);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0;border:1.5px solid var(--border)">?</div>';
    }
    html += '<div class="game-info">';
    html += '<div class="game-name">' + esc(g.name) + '</div>';
    html += '<div class="game-slug">' + esc(g.slug) + '</div>';
    html += '</div>';
    html += '<div class="game-actions">';
    html += '<label class="toggle" title="' + (g.active !== false ? 'Actif' : 'Inactif') + '"><input type="checkbox" ' + (g.active !== false ? 'checked' : '') + ' onchange="toggleActive(' + g.id + ',this.checked)"><span class="slider"></span></label>';
    html += '<button class="btn-primary btn-sm" onclick="openEditModal(' + g.id + ')">Edit</button>';
    html += '<button class="btn-danger btn-sm" onclick="deleteGame(' + g.id + ')">X</button>';
    html += '</div>';
    html += '</div>';
  }
  list.innerHTML = html;
}

// ══════════════════════════════════════════════
// ─── IMAGE UPLOAD ───
// ══════════════════════════════════════════════

function handleImageUpload(input, mode) {
  var file = input.files && input.files[0];
  if (!file) return;

  // Validate file type
  var allowed = ['image/jpeg','image/png','image/gif','image/webp'];
  if (allowed.indexOf(file.type) === -1) {
    showToast('Format non supporte. Utilisez JPG, PNG, GIF ou WebP.', 'error');
    input.value = '';
    return;
  }

  // Validate file size (2MB)
  if (file.size > 2 * 1024 * 1024) {
    showToast('Fichier trop volumineux. Maximum 2 Mo.', 'error');
    input.value = '';
    return;
  }

  // Show local preview immediately
  var reader = new FileReader();
  reader.onload = function(e) {
    var previewEl = document.getElementById(mode + 'ImgPreview');
    previewEl.querySelector('img').src = e.target.result;
    previewEl.classList.add('active');
  };
  reader.readAsDataURL(file);

  // Show progress
  var progressEl = document.getElementById(mode + 'ImgProgress');
  var fillEl = document.getElementById(mode + 'ImgFill');
  var statusEl = document.getElementById(mode + 'ImgStatus');
  var zoneEl = document.getElementById(mode + 'ImgZone');

  progressEl.classList.add('active');
  zoneEl.classList.add('uploading');
  fillEl.style.width = '30%';
  statusEl.textContent = 'Lecture du fichier...';

  fillEl.style.width = '60%';
  statusEl.textContent = 'Upload en cours...';

  var formData = new FormData();
  formData.append('image', file, file.name);
  fetch('/api/upload', {
      method: 'POST',
      headers: { 'X-CSRF-Token': CSRF },
      body: formData
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      progressEl.classList.remove('active');
      zoneEl.classList.remove('uploading');

      if (data.success) {
        // Put the URL in the image URL field
        document.getElementById(mode + 'Image').value = data.url;
        fillEl.style.width = '100%';
        statusEl.textContent = 'Image uploadee avec succes !';
        showToast('Image uploadee !', 'success');
      } else {
        statusEl.textContent = '';
        showToast(data.error || 'Erreur upload', 'error');
      }
      input.value = '';
    })
    .catch(function(err) {
      progressEl.classList.remove('active');
      zoneEl.classList.remove('uploading');
      showToast('Erreur reseau', 'error');
      input.value = '';
    });
}

function removeImage(mode) {
  var previewEl = document.getElementById(mode + 'ImgPreview');
  previewEl.querySelector('img').src = '';
  previewEl.classList.remove('active');
  document.getElementById(mode + 'Image').value = '';
}

// ══════════════════════════════════════════════
// ─── HTML FILE IMPORT ───
// ══════════════════════════════════════════════

function handleHtmlImport(input, mode) {
  var file = input.files && input.files[0];
  if (!file) return;

  // Validate file extension
  var name = file.name.toLowerCase();
  if (name.endsWith('.html') || name.endsWith('.htm')) {
    var reader = new FileReader();
    reader.onload = function(e) {
      document.getElementById(mode + 'Html').value = e.target.result;
      showToast('Fichier HTML importe : ' + file.name, 'success');
    };
    reader.onerror = function() {
      showToast('Erreur lors de la lecture du fichier', 'error');
    };
    reader.readAsText(file);
  } else {
    showToast('Veuillez selectionner un fichier .html ou .htm', 'error');
  }
  input.value = '';
}

// ─── Add Game ───
function addGame() {
  var name = document.getElementById('addName').value.trim();
  var slug = document.getElementById('addSlug').value.trim().toLowerCase().replace(/[^a-z0-9\-_]/g, '-');
  var image_url = document.getElementById('addImage').value.trim();
  var game_html = document.getElementById('addHtml').value;

  if (!name) { showToast('Le nom est requis', 'error'); return; }
  if (!slug) { showToast('Le slug est requis', 'error'); return; }

  apiCall('add', { name: name, slug: slug, image_url: image_url, game_html: game_html }, function(data) {
    if (data.success) {
      document.getElementById('addName').value = '';
      document.getElementById('addSlug').value = '';
      document.getElementById('addImage').value = '';
      document.getElementById('addHtml').value = '';
      removeImage('add');
      showToast('Jeu ajoute avec succes !', 'success');
      loadGames();
    } else {
      showToast(data.error || 'Erreur', 'error');
    }
  });
}

// ─── Edit Game ───
function openEditModal(id) {
  var game = allGames.find(function(g) { return g.id === id; });
  if (!game) return;

  document.getElementById('editId').value = id;
  document.getElementById('editName').value = game.name;
  document.getElementById('editImage').value = game.image_url || '';
  document.getElementById('editHtml').value = 'Chargement...';

  // Show existing image preview if there is one
  if (game.image_url) {
    var previewEl = document.getElementById('editImgPreview');
    previewEl.querySelector('img').src = game.image_url;
    previewEl.classList.add('active');
  } else {
    removeImage('edit');
  }

  document.getElementById('editModal').classList.add('show');

  // Load HTML separately from API (stored in a private file)
  fetch('/api/games?admin=1&read_html=' + encodeURIComponent(game.slug))
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.success && data.html) {
        document.getElementById('editHtml').value = data.html;
      } else {
        document.getElementById('editHtml').value = '';
      }
    })
    .catch(function() {
      document.getElementById('editHtml').value = '';
    });
}

function closeEditModal() {
  document.getElementById('editModal').classList.remove('show');
  removeImage('edit');
}

function saveGame() {
  var id = parseInt(document.getElementById('editId').value);
  var name = document.getElementById('editName').value.trim();
  var image_url = document.getElementById('editImage').value.trim();
  var game_html = document.getElementById('editHtml').value;

  if (!name) { showToast('Le nom est requis', 'error'); return; }

  apiCall('edit', { game_id: id, name: name, image_url: image_url, game_html: game_html }, function(data) {
    if (data.success) {
      closeEditModal();
      showToast('Jeu modifie !', 'success');
      loadGames();
    } else {
      showToast(data.error || 'Erreur', 'error');
    }
  });
}

// ─── Delete Game ───
function deleteGame(id) {
  var game = allGames.find(function(g) { return g.id === id; });
  if (!game) return;
  if (!confirm('Supprimer "' + game.name + '" ?')) return;

  apiCall('delete', { game_id: id }, function(data) {
    if (data.success) {
      showToast('Jeu supprime', 'success');
      loadGames();
    } else {
      showToast(data.error || 'Erreur', 'error');
    }
  });
}

// ─── Toggle Active ───
function toggleActive(id, active) {
  apiCall('edit', { game_id: id, active: active }, function(data) {
    loadGames();
  });
}

// ─── API Call ───
function apiCall(action, body, callback) {
  body.action = action;
  fetch('/api/games', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF },
    body: JSON.stringify(body)
  })
  .then(function(r) { return r.json(); })
  .then(callback)
  .catch(function(e) {
    console.error(e);
    showToast('Erreur reseau', 'error');
  });
}

// ─── Toast ───
function showToast(msg, type) {
  var toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.className = 'toast ' + (type || 'success');
  toast.classList.add('show');
  setTimeout(function() { toast.classList.remove('show'); }, 3000);
}

// ─── Utils ───
function esc(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ─── Restore authenticated session or show web setup ───
checkSetupStatus();
loadGames();
</script>
</body>
</html>
