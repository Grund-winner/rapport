<?php
declare(strict_types=1);

const ROVAS_MAX_JSON_BYTES = 6_000_000;
const ROVAS_MAX_HTML_BYTES = 2_000_000;
const ROVAS_MAX_IMAGE_BYTES = 2_000_000;

define('ROVAS_ROOT', dirname(__DIR__));
define('ROVAS_PUBLIC', ROVAS_ROOT . DIRECTORY_SEPARATOR . 'public');
define('ROVAS_STORAGE', ROVAS_ROOT . DIRECTORY_SEPARATOR . 'storage');
define('ROVAS_DATA_DIR', ROVAS_STORAGE . DIRECTORY_SEPARATOR . 'data');
define('ROVAS_IMAGES_DIR', ROVAS_STORAGE . DIRECTORY_SEPARATOR . 'images');
define('ROVAS_HTML_DIR', ROVAS_STORAGE . DIRECTORY_SEPARATOR . 'games_html');
define('ROVAS_GAMES_FILE', ROVAS_DATA_DIR . DIRECTORY_SEPARATOR . 'games.json');

function rovas_is_https(): bool
{
    return (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
        || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;
}

function rovas_security_headers(): void
{
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('Content-Security-Policy: default-src \'self\'; base-uri \'self\'; object-src \'none\'; frame-ancestors \'self\'; form-action \'self\'; img-src \'self\' https: data:; style-src \'self\' \'unsafe-inline\' https://fonts.googleapis.com; font-src \'self\' https://fonts.gstatic.com; script-src \'self\' \'unsafe-inline\' https://telegram.org; connect-src \'self\' https:; frame-src \'self\' https:');

    if (rovas_is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function rovas_bootstrap(): void
{
    rovas_security_headers();

    if (session_status() === PHP_SESSION_NONE) {
        $secure = rovas_is_https();
        session_name('rovas_session');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }
}

function rovas_env(string $key): ?string
{
    $value = getenv($key);
    if ($value === false || trim($value) === '') {
        return null;
    }

    return trim($value);
}

function rovas_admin_password_hash(): ?string
{
    $direct = rovas_env('ROVAS_ADMIN_PASSWORD_HASH');
    if ($direct !== null) {
        return $direct;
    }

    $hashFile = rovas_env('ROVAS_ADMIN_PASSWORD_HASH_FILE');
    if ($hashFile !== null && is_file($hashFile) && is_readable($hashFile)) {
        $contents = trim((string) file_get_contents($hashFile));
        return $contents !== '' ? $contents : null;
    }

    $localHashFile = ROVAS_DATA_DIR . DIRECTORY_SEPARATOR . 'admin-password.hash';
    if (is_file($localHashFile) && is_readable($localHashFile)) {
        $contents = trim((string) file_get_contents($localHashFile));
        return $contents !== '' ? $contents : null;
    }

    return null;
}

function rovas_admin_is_configured(): bool
{
    return rovas_admin_password_hash() !== null;
}

function rovas_json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function rovas_error(string $message, int $status = 400): never
{
    rovas_json_response(['error' => $message], $status);
}

function rovas_request_body(): array
{
    $length = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if ($length > ROVAS_MAX_JSON_BYTES) {
        rovas_error('Request too large', 413);
    }

    $raw = file_get_contents('php://input');
    if ($raw === false || strlen($raw) > ROVAS_MAX_JSON_BYTES) {
        rovas_error('Request too large', 413);
    }

    $body = json_decode($raw ?: '', true);
    if (!is_array($body)) {
        rovas_error('Invalid JSON', 400);
    }

    return $body;
}

function rovas_method(string $method): bool
{
    return strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET')) === strtoupper($method);
}

function rovas_ensure_storage(): void
{
    foreach ([ROVAS_DATA_DIR, ROVAS_IMAGES_DIR, ROVAS_HTML_DIR] as $directory) {
        if (!is_dir($directory)) {
            mkdir($directory, 0750, true);
        }
    }

    if (!is_file(ROVAS_GAMES_FILE)) {
        rovas_atomic_write(ROVAS_GAMES_FILE, "[]\n");
    }
}

function rovas_atomic_write(string $path, string $contents): void
{
    $directory = dirname($path);
    $temp = tempnam($directory, '.rovas-');
    if ($temp === false) {
        throw new RuntimeException('Unable to create temporary storage file');
    }

    try {
        if (file_put_contents($temp, $contents, LOCK_EX) === false || !rename($temp, $path)) {
            throw new RuntimeException('Unable to write storage file');
        }
        @chmod($path, 0640);
    } finally {
        if (is_file($temp)) {
            @unlink($temp);
        }
    }
}

function rovas_read_games(): array
{
    rovas_ensure_storage();
    $handle = fopen(ROVAS_GAMES_FILE, 'rb');
    if ($handle === false) {
        throw new RuntimeException('Unable to read game catalog');
    }

    try {
        flock($handle, LOCK_SH);
        $contents = stream_get_contents($handle);
        flock($handle, LOCK_UN);
    } finally {
        fclose($handle);
    }

    $games = json_decode($contents ?: '[]', true);
    if (!is_array($games)) {
        throw new RuntimeException('Game catalog is not valid JSON');
    }

    return array_values(array_filter($games, static fn ($game): bool => is_array($game)));
}

function rovas_write_games(array $games): void
{
    $json = json_encode(array_values($games), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        throw new RuntimeException('Unable to encode game catalog');
    }
    rovas_atomic_write(ROVAS_GAMES_FILE, $json . "\n");
}

function rovas_find_game_by_id(array $games, int $id): ?array
{
    foreach ($games as $game) {
        if ((int) ($game['id'] ?? 0) === $id) {
            return $game;
        }
    }

    return null;
}

function rovas_find_game_index(array $games, int $id): int
{
    foreach ($games as $index => $game) {
        if ((int) ($game['id'] ?? 0) === $id) {
            return $index;
        }
    }

    return -1;
}

function rovas_safe_slug(string $slug): string
{
    $slug = strtolower(trim($slug));
    $slug = preg_replace('/[^a-z0-9_-]+/', '-', $slug) ?? '';
    return trim($slug, '-_');
}

function rovas_valid_slug(string $slug): bool
{
    return (bool) preg_match('/^[a-z0-9][a-z0-9_-]{0,79}$/', $slug);
}

function rovas_normalize_image_url(string $value): string
{
    $value = trim($value);
    if ($value === '') {
        return '';
    }

    if (str_starts_with($value, 'api/')) {
        $value = '/' . $value;
    }

    if (str_starts_with($value, '/api/serve-image?file=')) {
        $file = substr($value, strlen('/api/serve-image?file='));
        if ($file !== '' && preg_match('/^[A-Za-z0-9._-]+$/', $file)) {
            return '/api/serve-image?file=' . $file;
        }
        return '';
    }

    $parts = parse_url($value);
    if (is_array($parts) && ($parts['scheme'] ?? '') === 'https' && !empty($parts['host'])) {
        return strlen($value) <= 2048 ? $value : '';
    }

    return '';
}

function rovas_safe_html(string $html): string
{
    if (strlen($html) > ROVAS_MAX_HTML_BYTES) {
        rovas_error('HTML file too large', 413);
    }

    if (preg_match('/<\?(?:php|=)?|<%/i', $html)) {
        rovas_error('Server-side code is not allowed in game HTML', 400);
    }

    return $html;
}

function rovas_game_html_path(string $slug): string
{
    if (!rovas_valid_slug($slug)) {
        rovas_error('Invalid slug', 400);
    }

    return ROVAS_HTML_DIR . DIRECTORY_SEPARATOR . $slug . '.html';
}

function rovas_save_game_html(string $slug, string $html): void
{
    $path = rovas_game_html_path($slug);
    $html = rovas_safe_html($html);
    if (file_put_contents($path, $html, LOCK_EX) === false) {
        throw new RuntimeException('Unable to save game HTML');
    }
    @chmod($path, 0640);
}

function rovas_delete_game_html(string $slug): void
{
    $path = rovas_game_html_path($slug);
    if (is_file($path) && !unlink($path)) {
        throw new RuntimeException('Unable to delete game HTML');
    }
}

function rovas_csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return (string) $_SESSION['csrf_token'];
}

function rovas_require_csrf(): void
{
    $provided = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $expected = (string) ($_SESSION['csrf_token'] ?? '');
    if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
        rovas_error('Invalid CSRF token', 403);
    }
}

function rovas_is_admin(): bool
{
    return !empty($_SESSION['admin_authenticated'])
        && !empty($_SESSION['admin_authenticated_at'])
        && (time() - (int) $_SESSION['admin_authenticated_at']) < 7200;
}

function rovas_require_admin(): void
{
    if (!rovas_is_admin()) {
        rovas_error('Unauthorized', 401);
    }
}

function rovas_client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
}

function rovas_rate_limit(string $scope, int $limit, int $windowSeconds): void
{
    $key = hash('sha256', $scope . '|' . rovas_client_ip());
    $path = ROVAS_DATA_DIR . DIRECTORY_SEPARATOR . 'rate-' . $key . '.json';
    $now = time();
    $handle = fopen($path, 'c+');
    if ($handle === false) {
        return;
    }

    try {
        flock($handle, LOCK_EX);
        $contents = stream_get_contents($handle);
        $state = json_decode($contents ?: '', true);
        if (!is_array($state) || $now - (int) ($state['started'] ?? 0) >= $windowSeconds) {
            $state = ['started' => $now, 'count' => 0];
        }
        $state['count'] = (int) ($state['count'] ?? 0) + 1;
        ftruncate($handle, 0);
        rewind($handle);
        fwrite($handle, json_encode($state));
        fflush($handle);
        flock($handle, LOCK_UN);
    } finally {
        fclose($handle);
    }

    if ((int) $state['count'] > $limit) {
        header('Retry-After: ' . max(1, $windowSeconds - ($now - (int) $state['started'])));
        rovas_error('Too many requests', 429);
    }
}

function rovas_admin_login(string $password): array
{
    $hash = rovas_admin_password_hash();
    if ($hash === null) {
        return ['ok' => false, 'status' => 503, 'error' => 'Admin password is not configured'];
    }

    if (!password_verify($password, $hash)) {
        return ['ok' => false, 'status' => 403, 'error' => 'Invalid credentials'];
    }

    session_regenerate_id(true);
    $_SESSION['admin_authenticated'] = true;
    $_SESSION['admin_authenticated_at'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    return ['ok' => true, 'csrf' => (string) $_SESSION['csrf_token']];
}

function rovas_setup_admin(string $setupKey, string $password): array
{
    if (rovas_admin_is_configured()) {
        return ['ok' => false, 'status' => 409, 'error' => 'Admin is already configured'];
    }

    $expectedKey = rovas_env('ROVAS_SETUP_KEY');
    if ($expectedKey === null || !hash_equals($expectedKey, $setupKey)) {
        return ['ok' => false, 'status' => 403, 'error' => 'Web setup is not authorized'];
    }
    if (strlen($password) < 16 || strlen($password) > 256) {
        return ['ok' => false, 'status' => 400, 'error' => 'Use a password between 16 and 256 characters'];
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    if ($hash === false) {
        return ['ok' => false, 'status' => 500, 'error' => 'Unable to configure admin'];
    }
    rovas_atomic_write(ROVAS_DATA_DIR . DIRECTORY_SEPARATOR . 'admin-password.hash', $hash . "\n");
    @chmod(ROVAS_DATA_DIR . DIRECTORY_SEPARATOR . 'admin-password.hash', 0640);

    $login = rovas_admin_login($password);
    return $login['ok']
        ? ['ok' => true, 'csrf' => $login['csrf']]
        : ['ok' => false, 'status' => 500, 'error' => 'Unable to start admin session'];
}

function rovas_public_games(array $games): array
{
    usort($games, static fn (array $a, array $b): int => ((int) ($a['sort_order'] ?? 0)) <=> ((int) ($b['sort_order'] ?? 0)));
    return array_values(array_map(static function (array $game): array {
        return [
            'id' => (int) ($game['id'] ?? 0),
            'slug' => (string) ($game['slug'] ?? ''),
            'name' => (string) ($game['name'] ?? ''),
            'image_url' => (string) ($game['image_url'] ?? ''),
            'sort_order' => (int) ($game['sort_order'] ?? 0),
        ];
    }, array_filter($games, static fn (array $game): bool => ($game['active'] ?? true) !== false)));
}

function rovas_admin_games(array $games): array
{
    usort($games, static fn (array $a, array $b): int => ((int) ($a['sort_order'] ?? 0)) <=> ((int) ($b['sort_order'] ?? 0)));
    return array_values(array_map(static function (array $game): array {
        unset($game['game_html']);
        return $game;
    }, $games));
}

function rovas_image_path(string $file): string
{
    if (!preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,180}$/', $file)) {
        rovas_error('Invalid file name', 400);
    }

    $path = ROVAS_IMAGES_DIR . DIRECTORY_SEPARATOR . $file;
    $real = realpath($path);
    $base = realpath(ROVAS_IMAGES_DIR);
    if ($real === false || $base === false || !str_starts_with($real, $base . DIRECTORY_SEPARATOR) || !is_file($real)) {
        rovas_error('Image not found', 404);
    }

    return $real;
}

rovas_ensure_storage();
rovas_bootstrap();