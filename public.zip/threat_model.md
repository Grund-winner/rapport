# Threat Model

## Project Overview

ROVAS Predictions is a PHP web application that serves a public catalog of game prediction pages and an authenticated browser-based admin dashboard. The app stores the game catalog as JSON, game HTML in private server storage, and images in private server storage exposed only through a validated image endpoint.

## Assets

- **Admin account and session** — controls the game catalog, game HTML, active state, and uploaded images.
- **Game HTML and image assets** — application content that is rendered to visitors; malicious content could become stored cross-site scripting.
- **Game catalog** — public product configuration and ordering; unauthorized edits could hide, replace, or redirect games.
- **Setup key and password hash** — credentials that protect first-run initialization and ongoing admin access.

## Trust Boundaries

- **Browser to PHP endpoints** — all request data, uploaded files, and HTML are untrusted.
- **Public visitor to admin surface** — public catalog routes must not expose catalog mutation or private storage.
- **PHP process to filesystem** — catalog and content writes must be constrained to the application storage directories and written atomically.
- **Admin-authored game HTML to the browser** — game pages intentionally execute client-side JavaScript, so this is a privileged content boundary.

## Scan Anchors

- Production entry points: `public/index.php`, `public/admin.php`, `public/api.php`.
- Highest-risk code: `src/bootstrap.php` storage, session, validation, and upload helpers; `public/api.php` mutation routes.
- Public surfaces: catalog, active game pages, and validated image serving.
- Authenticated surface: admin catalog reads, setup, CRUD, HTML reads, and image uploads.
- Dev-only surface: `router.php` is for PHP's built-in development server.

## Threat Categories

### Spoofing

Admin access MUST require a server-side session created by `password_verify`. Sessions MUST use HttpOnly and SameSite protections and regenerate their identifier after login. Login and setup attempts MUST be rate-limited. The setup key MUST be supplied through protected hosting configuration, never source code or a URL.

### Tampering

All catalog mutations MUST require authentication and a CSRF token. Slugs, names, URLs, sort orders, IDs, and active values MUST be validated server-side. Catalog writes MUST use atomic replacement and file locking. The client MUST NOT be trusted to enforce authorization or content constraints.

### Information Disclosure

Password hashes, setup state, JSON data, images, and game HTML storage MUST remain outside the public document root or be denied by server rules. API errors MUST not expose stack traces, secrets, or filesystem paths. The public API MUST return only active game metadata.

### Denial of Service

JSON requests, HTML content, and uploads MUST have bounded sizes. Login, setup, admin writes, and uploads MUST be rate-limited. Image uploads MUST be checked by decoded MIME type and image parsing rather than filename or browser-provided MIME alone.

### Elevation of Privilege

Every admin read and write MUST enforce the server-side session. File names and slugs MUST be allowlisted and resolved within their intended storage directories to prevent traversal. Uploaded SVG and other active image formats MUST be rejected. Game HTML MUST reject server-side code markers and be editable only by authenticated admins.