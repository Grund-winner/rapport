# ROVAS Predictions — PHP web app

This package preserves the original ROVAS Predictions catalog, game pages, admin dashboard, image uploads, and active/inactive game controls, but replaces the Cloudflare/GitHub runtime with a self-contained PHP storage layer.

## Browser-only setup

1. Set `ROVAS_SETUP_KEY` in your hosting provider's protected environment-variable/secrets screen. Use a long random value; never put it in the source code.
2. Point the web server document root at the `public/` folder.
3. Open `/admin.php` in a browser. Click **Premiere configuration**, enter the setup key, and create an admin password of at least 16 characters.
4. After setup, remove `ROVAS_SETUP_KEY` from the hosting environment. The saved password hash remains in the private `storage/data/` directory.

The setup flow is browser-only. No command-line setup is required.

## Web server requirements

- PHP 8.2+ with `fileinfo`, `session`, and `gd` enabled.
- `storage/` must be writable by PHP and must remain outside the public document root. The included deny rules are an additional safeguard when the package directory is used directly.
- Use HTTPS in production.
- For Apache, allow the included `public/.htaccess` rewrite rules.
- For Nginx, route `/api/games`, `/api/game-page`, `/api/serve-image`, and `/api/upload` to `public/api.php` and pass the `resource` query value, or use equivalent location rewrites.

## PHP development server

For local-only development, a PHP-enabled host can use the included `router.php` with the document root set to `public/`. The normal production deployment should use Apache or Nginx.

## Security protections

- No hard-coded admin password.
- Server-side `HttpOnly`, `SameSite=Strict` session cookies and session ID regeneration on login.
- CSRF token required for admin writes, logout, and uploads.
- Rate limiting for login, setup, writes, and uploads.
- Private JSON, HTML, image, and password-hash storage with path traversal protection.
- MIME sniffing and decoded-image validation for uploads; SVG is intentionally rejected because it can carry active scripts.
- Strict slug, name, URL, request-size, and HTML validation.
- Atomic catalog writes with file locks.
- Security headers including CSP, HSTS on HTTPS, clickjacking protection, and MIME sniffing protection.
- Generic production error responses that do not expose stack traces or secrets.

The game HTML files are intentionally allowed to run client-side JavaScript because that is how the supplied games operate. They are only editable by authenticated admins and are served with a restrictive document policy; do not import game HTML from untrusted sources.