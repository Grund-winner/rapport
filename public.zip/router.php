<?php
declare(strict_types=1);


$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$routes = [
    '#^/api/(games|game-page|serve-image|upload)/?$#' => static function (string $resource): void {
        $_GET['resource'] = $resource;
        require __DIR__ . '/public/api.php';
    },
];

foreach ($routes as $pattern => $handler) {
    if (preg_match($pattern, $path, $matches)) {
        $handler($matches[1]);
        return;
    }
}

if ($path === '/admin' || $path === '/admin/') {
    require __DIR__ . '/public/admin.php';
    return;
}

if ($path === '/' || $path === '/index.php') {
    require __DIR__ . '/public/index.php';
    return;
}

if (preg_match('#^/api/game-page/?$#', $path)) {
    $_GET['resource'] = 'game-page';
    require __DIR__ . '/public/api.php';
    return;
}

$candidate = __DIR__ . '/public' . $path;
if (is_file($candidate)) {
    return false;
}

http_response_code(404);
echo 'Not found';