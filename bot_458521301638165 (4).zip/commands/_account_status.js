/**#command
name: /account_status
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /account_status
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let profile = await syncUser();
let lang = User.get("language") || "fr";

let registered = profile.user?.registration_status === "registered";
let deposited = profile.user?.deposit_status === "deposited";
let credits = profile.credits?.balance || 0;
let lifetimeEarned = profile.credits?.lifetime_earned || 0;
let lifetimeUsed = profile.credits?.lifetime_used || 0;
let country = profile.user?.country || "—";
let oneWinId = profile.user?.one_win_user_id || "—";

let txt = `${EMOJI.chart} <b>${t("account_status")}</b>\n\n`;
txt += `${EMOJI.user} <b>${escapeHtml(user.first_name || "User")}</b>\n`;
txt += `${EMOJI.id} Telegram: <code>${user.id}</code>\n`;
txt += `${EMOJI.id} 1Win: <code>${oneWinId}</code>\n`;
txt += `${EMOJI.globe} ${lang === "fr" ? "Pays" : "Country"}: <code>${country}</code>\n\n`;

txt += `━━━━━━━━━━━━━━━━\n`;
txt += `${registered ? EMOJI.check : EMOJI.cross} ${lang === "fr" ? "Inscription" : "Registration"}: ${registered ? "Validée" : "En attente"}\n`;
txt += `${deposited ? EMOJI.check : EMOJI.cross} ${lang === "fr" ? "Dépôt" : "Deposit"}: ${deposited ? "Validé" : "En attente"}\n`;
txt += `━━━━━━━━━━━━━━━━\n\n`;

txt += `${EMOJI.target} ${t("remaining_credits")}: <b>${credits}</b>\n`;
txt += `${EMOJI.chart_up} ${lang === "fr" ? "Total reçu" : "Total earned"}: ${lifetimeEarned}\n`;
txt += `${EMOJI.chart_down} ${lang === "fr" ? "Total utilisé" : "Total used"}: ${lifetimeUsed}\n\n`;

if (!registered) txt += `${EMOJI.point_right} ${t("register_first")} <b>${CONFIG.PROMO_CODE}</b>`;
else if (!deposited) txt += `${EMOJI.point_right} ${t("deposit_first")} <b>$${CONFIG.MIN_DEPOSIT}</b>`;
else txt += `${EMOJI.check} ${t("account_approved")}`;

let kb = [[btnT("back", "arrow_left", "/main")]];

if (!registered || !deposited) {
  kb.unshift([btnUrl(
    registered ? (lang === "fr" ? "Déposer" : "Deposit") : tText("registration"),
    registered ? "money" : "phone",
    CONFIG.REG_LINK_TEMPLATE.replace("{TELEGRAM_ID}", String(user.id))
  )]);
}

smartMedia({
  text: txt,
  video: CONFIG.ACCOUNT_STATUS_VIDEO || undefined,
  photo: !CONFIG.ACCOUNT_STATUS_VIDEO ? (CONFIG.ACCOUNT_STATUS_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: kb }
});