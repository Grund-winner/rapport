/**#command
name: /badges
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /badges
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/
let lang = User.get("language") || "fr";
let result = await apiGet(`/api/bot/badges/${user.id}`);
if (!result.ok || !Array.isArray(result.badges)) {
  return smartMedia({ text: `${EMOJI.cross_circle} ${t("badges_unavailable")}`, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[btnT('back', 'arrow_left', '/main')]] } });
}
const badgeMeta = {
  first_share: [EMOJI.sparkles, t("first_share")],
  first_referral: [EMOJI.user_check, t("first_referral")],
  active_referrer: [EMOJI.streak, t("active_referrer")],
  ambassador: [EMOJI.diamond, t("ambassador")],
  top_three: [EMOJI.crown, t("top_three")]
};
let text = `${EMOJI.medal} <b>${t("my_badges")}</b>\n\n`;
for (const code of ['first_share', 'first_referral', 'active_referrer', 'ambassador', 'top_three']) {
  const meta = badgeMeta[code];
  const has = result.badges.includes(code);
  text += `${has ? EMOJI.unlock : EMOJI.lock} ${meta[0]} ${meta[1]}\n`;
}
return smartMedia({ text, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[btnCb(tText("leaderboard"), 'trophy', '/leaderboard')], [btnT('back', 'arrow_left', '/main')]] } });
