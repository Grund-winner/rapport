/**#command
name: /games
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /games
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /games
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /games
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let profile = await syncUser();
let lang = User.get("language") || "fr";

let registered = profile.user?.registration_status === "registered";
let deposited = profile.user?.deposit_status === "deposited";
let credits = profile.credits?.balance || 0;
let adminBypass = isAdmin(user.id);
let freeUsed = Math.max(0, parseInt(User.get("free_signals_used") || 0, 10));
let freeRemaining = Math.max(0, 3 - freeUsed);
let trialAvailable = freeRemaining > 0 && (!registered || !deposited);

if (!adminBypass && !trialAvailable && (!registered || !deposited)) {
  let txt = `${EMOJI.cross} <b>${t("access_denied")}</b>\n\n`;
  if (!registered) txt += `${t("register_first")} <b>${CONFIG.PROMO_CODE}</b>`;
  else txt += `${t("deposit_first")} <b>$${CONFIG.MIN_DEPOSIT}</b>`;
  let kb = [
    [btnUrl(registered ? tText("deposit_required") : tText("registration"),
      registered ? "money" : "phone",
      CONFIG.REG_LINK_TEMPLATE.replace("{TELEGRAM_ID}", String(user.id)))],
    [btnT("back", "arrow_left", "/main")]
  ];
  return smartMedia({
    text: txt,
    video: CONFIG.ACCESS_DENIED_VIDEO || undefined,
    photo: !CONFIG.ACCESS_DENIED_VIDEO ? (CONFIG.ACCESS_DENIED_IMAGE || undefined) : undefined,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: kb
    }
  });
}

// Catalogue local : les jeux sont connus à l'avance et ne dépendent plus de l'API.
// Pour ajouter ou retirer un jeu, modifie uniquement ce tableau.
const LOCAL_GAMES = [
  { game_key: "luckyjet", display_name: "Lucky Jet" },
  { game_key: "astronaut", display_name: "Astronaut" },
  { game_key: "crash", display_name: "Crash" },
  { game_key: "crimeempire", display_name: "Crime Empire" },
  { game_key: "fortunecrash", display_name: "Fortune Crash" },
  { game_key: "metacrash", display_name: "Meta Crash" },
  { game_key: "rocketqueen", display_name: "Rocket Queen" },
  { game_key: "rocketx", display_name: "Rocket X" },
  { game_key: "tropicana", display_name: "Tropicana" }
];

let games = LOCAL_GAMES;

let txt = `${EMOJI.game} <b>${t("select_game")}</b>\n\n`;
txt += `${EMOJI.target} ${t("remaining_credits")}: <b>${credits}</b>\n`;
if (trialAvailable) txt += `${EMOJI.gift} <b>${lang === "fr" ? "Signaux gratuits restants" : "Free signals remaining"}: ${freeRemaining}</b>\n\n`;
else txt += `\n`;
if (adminBypass) txt += `${EMOJI.check} <i>${t("admin_mode")}</i>\n\n`;
txt += `<i>${t("risk_warning")}</i>`;

let kb = [];
let row = [];
for (let i = 0; i < games.length; i++) {
  let g = games[i];
  row.push(btnCb(g.display_name, "smile", `/signal ${g.game_key}`));
  if (row.length === 2 || i === games.length - 1) {
    kb.push(row);
    row = [];
  }
}
kb.push([btnT("back", "arrow_left", "/main")]);

smartMedia({
  text: txt,
  video: CONFIG.GAMES_VIDEO || undefined,
  photo: !CONFIG.GAMES_VIDEO ? (CONFIG.GAMES_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: kb
  }
});