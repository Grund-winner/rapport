/**#command
name: /leaderboard
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /leaderboard
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/
let lang = User.get("language") || "fr";
let result = await apiGet('/api/bot/leaderboard', { period: 'weekly', limit: 10 });
if (!result.ok || !Array.isArray(result.entries)) {
  return smartMedia({ text: `${EMOJI.cross_circle} ${t("leaderboard_unavailable")}`, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[btnT('back', 'arrow_left', '/main')]] } });
}
let lines = `${EMOJI.trophy} <b>${t("weekly_leaderboard")}</b>\n\n`;
const rankIcons = { 1: EMOJI.rank_first, 2: EMOJI.rank_second, 3: EMOJI.rank_third };
for (let i = 0; i < result.entries.length; i++) {
  const row = result.entries[i] || {};
  const rank = Number(row.rank_position || i + 1);
  const icon = rankIcons[rank] || EMOJI.ranking;
  const name = escapeHtml(row.display_name || row.username || `User ${row.user_id || ''}`);
  const tickets = Number(row.tickets_earned || 0);
  lines += `${icon} <b>${rank}.</b> ${name} — ${EMOJI.ticket} <b>${tickets}</b>\n`;
}
if (!result.entries.length) lines += `${EMOJI.info} ${t("no_leaderboard_data")}\n`;
lines += `\n${EMOJI.calendar_week} <i>${t("tickets_validation")}</i>`;
return smartMedia({ text: lines, parse_mode: 'HTML', reply_markup: { inline_keyboard: [[btnT('referral', 'gift', '/referral')], [btnT('back', 'arrow_left', '/main')]] } });
