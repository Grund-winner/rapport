/**#command
name: /referral
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /referral
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /referral
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let lang = User.get("language") || "fr";

let result = await apiGet(`/api/bot/referral/${user.id}`);
let usingCache = false;

if (result.ok && result.referral) {
  // On conserve la dernière réponse valide pour les indisponibilités futures.
  User.set("referral_snapshot", result);
} else {
  const cachedReferral = User.get("referral_snapshot");
  if (cachedReferral && cachedReferral.referral) {
    result = cachedReferral;
    usingCache = true;
  }
}

if (!result.ok || !result.referral) {
  return smartMedia({
    text: `${EMOJI.cross} ${t("loading_error")}`,
    video: CONFIG.REFERRAL_VIDEO || undefined,
    photo: !CONFIG.REFERRAL_VIDEO ? (CONFIG.REFERRAL_IMAGE || undefined) : undefined,
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: [[btnT("back", "arrow_left", "/main")]] }
  });
}

let ref = result.referral;
let link = ref.referral_link || "";
let stats = ref.stats || {};

let txt = `${EMOJI.gift} <b>${t("referral")}</b>\n\n`;
txt += `━━━━━━━━━━━━━━━━━━\n`;
txt += `${EMOJI.link} <code>${link}</code>\n\n`;
txt += `${EMOJI.target} <b>${t("how_it_works")}:</b>\n`;
txt += `${EMOJI.megaphone} ${t("share_friends")}\n`;
txt += `${EMOJI.user} ${t("each_signup")}\n`;
txt += `${EMOJI.money} ${t("each_deposit")}\n\n`;
txt += `${EMOJI.chart} <b>${t("your_stats")}:</b>\n`;
txt += `${EMOJI.group} ${t("referrals")}: <b>${stats.total_referrals || 0}</b>\n`;
txt += `${EMOJI.check} ${t("signed_up")}: <b>${stats.signup_awarded || 0}</b>\n`;
txt += `${EMOJI.money_bag} ${t("deposited")}: <b>${stats.deposit_awarded || 0}</b>\n`;
if (usingCache) txt += `\n<i>${lang === "fr" ? "Dernière mise à jour disponible (API temporairement indisponible)." : "Showing the latest available update (API temporarily unavailable)."}</i>`;

let shareMsg = `${tPlain("share_msg")}\n\n${link}`;

let kb = [
  [btnShare(tText("share_link"), "outbox", shareMsg)],
  [
    btnCb(tText("leaderboard"), "trophy", "/leaderboard"),
    btnCb(tText("badges"), "medal", "/badges")
  ],
  [btnT("back", "arrow_left", "/main")]
];

smartMedia({
  text: txt,
  video: CONFIG.REFERRAL_VIDEO || undefined,
  photo: !CONFIG.REFERRAL_VIDEO ? (CONFIG.REFERRAL_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: kb }
});