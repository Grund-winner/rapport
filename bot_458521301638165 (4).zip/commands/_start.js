/**#command
name: /start
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /start
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let lang = User.get("language") || "fr";

const paramsStr = (params || "").trim();
let referrerId = null;
if (paramsStr.startsWith("ref_")) {
  const id = parseInt(paramsStr.replace("ref_", ""), 10);
  if (Number.isFinite(id) && id > 0) {
    referrerId = id;
    User.set("referrer_id", id);
  }
}

let profile = await syncUser();

let joinedRecently = User.get("joined_channel_at");
let now = Date.now();
let needCheck = !joinedRecently || (now - parseInt(joinedRecently)) > 5 * 60 * 1000;

let joined = false;
if (needCheck) {
  try {
    let member = await Api.getChatMember({
      chat_id: CONFIG.CHANNEL_USERNAME,
      user_id: user.id
    });
    joined = ["member", "administrator", "creator"].includes(member.result.status);
    if (joined) User.set("joined_channel_at", String(now));
  } catch (e) { joined = false; }
} else { joined = true; }

if (!joined) {
  return smartMedia({
    text: t("must_join"),
    video: CONFIG.VERIFY_JOIN_VIDEO || undefined,
    photo: !CONFIG.VERIFY_JOIN_VIDEO ? (CONFIG.VERIFY_JOIN_IMAGE || undefined) : undefined,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
        [btnUrl(lang === "fr" ? "Rejoindre le canal" : "Join Channel", "megaphone", CONFIG.CHANNEL_LINK)],
        [btnT("joined", "check", "/verify_join")]
      ]
    }
  });
}

if (!lang) { Bot.runCommand("/language"); return; }
Bot.runCommand("/main");