/**#command
name: /signal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /signal
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /signal
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let parts = (params || "").trim().split(/\s+/);
let gameKey = parts[0];
let range = parts[1];
let lang = User.get("language") || "fr";

// Identifiants internes des tranches pour la génération locale.
// On conserve la compatibilité avec les anciennes commandes numériques.
const RANGE_ALIASES = {
  "1-2": "low",
  "2-10": "mid",
  "10-100": "high"
};
if (range) range = RANGE_ALIASES[range] || range.toLowerCase();

const RANDOM_RANGES = {
  low: { min: 1, max: 2, confidenceMin: 82, confidenceMax: 96 },
  mid: { min: 2, max: 10, confidenceMin: 68, confidenceMax: 88 },
  high: { min: 10, max: 100, confidenceMin: 45, confidenceMax: 72 }
};

function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

function utcTime(date) {
  return date.toISOString().slice(11, 16);
}

function displayGameName(key) {
  const names = {
    luckyjet: "Lucky Jet",
    astronaut: "Astronaut",
    crash: "Crash",
    crimeempire: "Crime Empire",
    fortunecrash: "Fortune Crash",
    metacrash: "Meta Crash",
    rocketqueen: "Rocket Queen",
    rocketx: "Rocket X",
    tropicana: "Tropicana"
  };
  return names[key] || String(key).replace(/[-_]/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

if (!gameKey) {
  Bot.runCommand("/games");
  return;
}

if (!range) {
  let profile = await syncUser();
  let adminBypass = isAdmin(user.id);
  let registered = profile.user?.registration_status === "registered";
  let deposited = profile.user?.deposit_status === "deposited";
  let freeUsed = Math.max(0, parseInt(User.get("free_signals_used") || 0, 10));
  let freeRemaining = Math.max(0, 3 - freeUsed);
  let trialAvailable = freeRemaining > 0 && (!registered || !deposited);

  if (!adminBypass && !trialAvailable && (!registered || !deposited)) {
    let txt = `${EMOJI.cross} <b>${t("access_denied")}</b>\n\n`;
    if (!registered) txt += `${t("register_first")} <b>${CONFIG.PROMO_CODE}</b>`;
    else txt += `${t("deposit_first")} <b>$${CONFIG.MIN_DEPOSIT}</b>`;
    let kb = [
      [btnT("back", "arrow_left", "/games")]
    ];
    return smartMedia({
      text: txt,
      video: CONFIG.ACCESS_DENIED_VIDEO || undefined,
      photo: !CONFIG.ACCESS_DENIED_VIDEO ? (CONFIG.ACCESS_DENIED_IMAGE || undefined) : undefined,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: kb
      }
    });
  }

  let gameName = displayGameName(gameKey);

  let txt = `${EMOJI.gear} <b>${t("select_range")}</b>\n`;
  txt += `${EMOJI.game} <b>${gameName}</b>\n\n`;
  txt += `━━━━━━━━━━━\n`;

  let kb = [
    [btnCb(tText("range_low"), "blue", `/signal ${gameKey} low`)],
    [btnCb(tText("range_mid"), "purple", `/signal ${gameKey} mid`)],
    [btnCb(tText("range_high"), "orange", `/signal ${gameKey} high`)],
    [btnT("back", "arrow_left", "/games")]
  ];

  return smartMedia({
    text: txt,
    video: CONFIG.RANGE_VIDEO || undefined,
    photo: !CONFIG.RANGE_VIDEO ? (CONFIG.RANGE_IMAGE || undefined) : undefined,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: kb
    }
  });
}

let profile = await syncUser();
let userId = profile.user?.id;
let credits = profile.credits?.balance || 0;
let adminBypass = isAdmin(user.id);
let registered = profile.user?.registration_status === "registered";
let deposited = profile.user?.deposit_status === "deposited";
let freeUsed = Math.max(0, parseInt(User.get("free_signals_used") || 0, 10));
let freeRemaining = Math.max(0, 3 - freeUsed);
let trialAvailable = freeRemaining > 0 && (!registered || !deposited);

let lastTime = User.get("last_sig_time") || 0;
let now = Date.now();
let cooldown = CONFIG.COOLDOWN_SEC * 1000;

if (!adminBypass && (now - parseInt(lastTime) < cooldown)) {
  let wait = Math.ceil((cooldown - (now - parseInt(lastTime))) / 1000);
  Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: "⏳ " + (lang === "fr" ? "Patientez" : "Wait") + " " + wait + "s " + (lang === "fr" ? "avant le prochain signal" : "before next signal"),
    show_alert: true
  });
  return;
}

if (credits < 1 && !adminBypass && !trialAvailable) {
  Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: lang === "fr" ?
      "❌ Plus de signaux disponibles.\n\n💡 Invite un ami = +1 signal\n💰 Effectue un dépôt = +1 signal par $" :
      "❌ No more signals.\n\n💡 Invite a friend = +1 signal\n💰 Make a deposit = +1 signal per $",
    show_alert: true
  });
  // Affiche le menu de parrainage au lieu de rester bloqué
  Bot.runCommand("/referral");
  return;
}

const rangeConfig = RANDOM_RANGES[range];
if (!rangeConfig) {
  Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: "Tranche invalide",
    show_alert: true
  });
  return;
}

const targetMin = randomBetween(rangeConfig.min, rangeConfig.max);
const targetMax = randomBetween(targetMin, rangeConfig.max);
const assurance = randomBetween(rangeConfig.min, targetMin);
const confidence = Math.round(randomBetween(rangeConfig.confidenceMin, rangeConfig.confidenceMax));
const validFrom = new Date(now + 5 * 60 * 1000);
const validUntil = new Date(now + 10 * 60 * 1000);

let result = {
  ok: true,
  signal: {
    display_name: displayGameName(gameKey),
    prediction: {
      valid_from: utcTime(validFrom),
      valid_until: utcTime(validUntil),
      cote_min: Math.min(targetMin, targetMax),
      cote_max: Math.max(targetMin, targetMax),
      assurance: assurance,
      confidence: confidence,
      category: range === "low" ? "blue" : range === "mid" ? "purple" : "orange"
    }
  }
};

User.set("last_sig_time", String(now));
if (trialAvailable) User.set("free_signals_used", String(freeUsed + 1));

let sig = result.signal;
let p = sig.prediction;

let catEmojiKey = {
  blue: 'blue',
  purple: 'purple',
  orange: 'orange'
} [p.category] || 'target';
let catEmoji = EMOJI[catEmojiKey];

let gameName = sig.display_name.toUpperCase();

// === FORMAT SIGNAL — tout en gras, emojis premium ===
let txt = `<b>┏━━━━━━━━━━┓\n`;
txt += `  ${EMOJI.target} ${gameName} SIGNAL\n`;
txt += `┗━━━━━━━━━━┛\n`;

txt += `${EMOJI.hourglass} <code>${p.valid_from} → ${p.valid_until}</code> UTC\n`;

txt += `    ╭─〔 TARGET 〕─╮\n`;
txt += `     ${catEmoji} ${p.cote_min.toFixed(2)}x → ${p.cote_max.toFixed(2)}x\n`;
txt += `    ╰──── ────╯\n`;

txt += `╭─〔 SAFE POINT 〕─╮\n`;
txt += `              ${EMOJI.check} ${p.assurance.toFixed(2)}x\n`;
txt += `╰───── ─────╯\n`;

txt += `    ${EMOJI.target} ${t("confidence")} ›  ${p.confidence}%</b>\n`;

let kb = [
  [btnCb(tText("new_signal"), "refresh", `/signal ${gameKey} ${range}`)],
  [btnCb(tText("other_games"), "game", "/games")],
  [btnT("back", "arrow_left", `/signal ${gameKey}`)]
];

Api.answerCallbackQuery({
  callback_query_id: request.id,
  text: "✅"
});

let gameVideo = (CONFIG.GAME_VIDEOS && CONFIG.GAME_VIDEOS[gameKey]) || undefined;

smartMedia({
  text: txt,
  video: gameVideo,
  photo: !gameVideo ? (CONFIG.MAIN_MENU_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: kb
  }
});