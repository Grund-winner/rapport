/**#command
name: /langset
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /langset
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

const lang = (params || "").trim().toLowerCase();
const supported = ["fr", "en", "es", "pt", "ru", "hi"];

if (!supported.includes(lang)) {
  return Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: "❌ Invalid language",
    show_alert: true
  });
}

User.set("language", lang);

try {
  await apiGet(`/api/bot/users/${user.id}/status`, {
    username: user.username || '',
    first_name: user.first_name || '',
    language: lang
  });
} catch (e) {}

Api.answerCallbackQuery({
  callback_query_id: request.id,
  text: "✅ " + (lang === "fr" ? "Langue enregistrée" : "Language saved")
});

try {
  await Api.deleteMessage({ chat_id: chat.id, message_id: request.message.message_id });
} catch (e) {}

Bot.runCommand("/main");