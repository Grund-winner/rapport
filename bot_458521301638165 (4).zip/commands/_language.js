/**#command
name: /language
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /language
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

smartMedia({
  text: "🌐 <b>" + (User.get("language") === "en" ? "Select your language" : "Sélectionnez votre langue") + "</b>",
  video: CONFIG.LANGUAGE_VIDEO || undefined,
  photo: !CONFIG.LANGUAGE_VIDEO ? (CONFIG.LANGUAGE_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: {
    inline_keyboard: [
      [
        btnCb("Français", "flag_fr", "/langset fr"),
        btnCb("English", "flag_gb", "/langset en")
      ],
      [
        btnCb("Español", "flag_es", "/langset es"),
        btnCb("Português", "flag_pt", "/langset pt")
      ],
      [
        btnCb("Русский", "flag_ru", "/langset ru"),
        btnCb("हिन्दी", "flag_in", "/langset hi")
      ]
    ]
  }
});