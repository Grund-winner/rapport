/**#command
name: @
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: @
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: @
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

const CONFIG = {
  OWNER_ID: 2120696159,
  PROMO_CODE: "DNS25",
  CHANNEL_USERNAME: "@DNS25ch",
  CHANNEL_LINK: "https://t.me/+jqs0HBWL3Vg5OGJk",
  REG_LINK_TEMPLATE: "https://1wande.com/?p=ltw5&sub1={TELEGRAM_ID}",
  ADMIN_CONTACT: "https://t.me/DSC_777",
  API_URL: "https://dns25-bot.danescottcody.workers.dev",
  API_SECRET: "358e281be746a41d7675432491fa8d3402473563a043acfcf0ccd02d4e039762",
  COOLDOWN_SEC: 60,
  MIN_DEPOSIT: "5",
  WELCOME_VIDEO: "",
  WELCOME_IMAGE: "",
  MAIN_MENU_VIDEO: "",
  MAIN_MENU_IMAGE: "",
  GAMES_VIDEO: "",
  GAMES_IMAGE: "",
  RANGE_VIDEO: "",
  RANGE_IMAGE: "",
  INSTRUCTION_VIDEO: "",
  INSTRUCTION_IMAGE: "",
  PROFILE_VIDEO: "",
  PROFILE_IMAGE: "",
  REFERRAL_VIDEO: "",
  REFERRAL_IMAGE: "",
  ACCOUNT_STATUS_VIDEO: "",
  ACCOUNT_STATUS_IMAGE: "",
  LANGUAGE_VIDEO: "",
  LANGUAGE_IMAGE: "",
  VERIFY_JOIN_VIDEO: "",
  VERIFY_JOIN_IMAGE: "",
  ACCESS_DENIED_VIDEO: "",
  ACCESS_DENIED_IMAGE: "",
  GAME_VIDEOS: {
    luckyjet: "https://t.me/terderdns25/128",
    astronaut: "https://t.me/terderdns25/132",
    crash: "https://t.me/terderdns25/129",
    crimeempire: "https://t.me/terderdns25/135",
    fortunecrash: "https://t.me/terderdns25/134",
    metacrash: "https://t.me/terderdns25/136",
    rocketqueen: "https://t.me/terderdns25/130",
    rocketx: "https://t.me/terderdns25/131",
    tropicana: "https://t.me/terderdns25/133"
  }
};

function utf8ToBytes(str) {
  const bytes = [];
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    if (c < 0x80) bytes.push(c);
    else if (c < 0x800) { bytes.push(0xC0 | (c >> 6), 0x80 | (c & 0x3F)); }
    else if (c >= 0xD800 && c <= 0xDBFF) {
      i++;
      const c2 = str.charCodeAt(i);
      const cp = 0x10000 + ((c - 0xD800) << 10) + (c2 - 0xDC00);
      bytes.push(0xF0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3F), 0x80 | ((cp >> 6) & 0x3F), 0x80 | (cp & 0x3F));
    } else { bytes.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 0x3F), 0x80 | (c & 0x3F)); }
  }
  return bytes;
}
function bytesToHex(bytes) { return bytes.map(b => (b & 0xff).toString(16).padStart(2, '0')).join(''); }
function rotr32(x, n) { return ((x >>> n) | (x << (32 - n))) >>> 0; }
function sha256Bytes(bytes) {
  const K = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  let h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const L = bytes.length, BL = L * 8, PL = Math.ceil((L + 9) / 64) * 64;
  const p = new Array(PL).fill(0);
  for (let i = 0; i < L; i++) p[i] = bytes[i];
  p[L] = 0x80; p[PL-4] = (BL>>>24)&0xff; p[PL-3] = (BL>>>16)&0xff; p[PL-2] = (BL>>>8)&0xff; p[PL-1] = BL&0xff;
  for (let bs = 0; bs < PL; bs += 64) {
    const w = new Array(64);
    for (let i = 0; i < 16; i++) { const o = bs + i*4; w[i] = ((p[o]<<24)|(p[o+1]<<16)|(p[o+2]<<8)|p[o+3])>>>0; }
    for (let i = 16; i < 64; i++) { const s0 = rotr32(w[i-15],7)^rotr32(w[i-15],18)^(w[i-15]>>>3); const s1 = rotr32(w[i-2],17)^rotr32(w[i-2],19)^(w[i-2]>>>10); w[i] = (w[i-16]+s0+w[i-7]+s1)>>>0; }
    let a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
    for (let i = 0; i < 64; i++) {
      const S1 = rotr32(e,6)^rotr32(e,11)^rotr32(e,25); const ch = (e&f)^((~e)&g); const t1 = (hh+S1+ch+K[i]+w[i])>>>0;
      const S0 = rotr32(a,2)^rotr32(a,13)^rotr32(a,22); const maj = (a&b)^(a&c)^(b&c); const t2 = (S0+maj)>>>0;
      hh=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    h[0]=(h[0]+a)>>>0;h[1]=(h[1]+b)>>>0;h[2]=(h[2]+c)>>>0;h[3]=(h[3]+d)>>>0;h[4]=(h[4]+e)>>>0;h[5]=(h[5]+f)>>>0;h[6]=(h[6]+g)>>>0;h[7]=(h[7]+hh)>>>0;
  }
  const r = []; for (let i = 0; i < 8; i++) r.push((h[i]>>>24)&0xff,(h[i]>>>16)&0xff,(h[i]>>>8)&0xff,h[i]&0xff);
  return r;
}
function sha256Hex(str) { return bytesToHex(sha256Bytes(utf8ToBytes(str))); }
function hmacSha256Hex(secret, message) {
  let k = utf8ToBytes(secret);
  if (k.length > 64) k = sha256Bytes(k);
  while (k.length < 64) k.push(0);
  const ip = [], op = [];
  for (let i = 0; i < 64; i++) { ip.push(k[i]^0x36); op.push(k[i]^0x5c); }
  return bytesToHex(sha256Bytes(op.concat(sha256Bytes(ip.concat(utf8ToBytes(message))))));
}
function hmacSign(secret, message) { return hmacSha256Hex(secret, message); }
function sha256HexSync(str) { return sha256Hex(str); }

async function smartMessage(data) {
  const msgId = request?.message?.message_id;
  if (msgId) {
    try {
      const edit = await Api.editMessageText({
        chat_id: chat.id, message_id: msgId,
        text: data.text, parse_mode: data.parse_mode || "HTML",
        reply_markup: data.reply_markup,
        disable_web_page_preview: data.disable_web_page_preview !== false
      });
      if (edit && edit.ok) return edit;
    } catch (e) {}
    try { await Api.deleteMessage({ chat_id: chat.id, message_id: msgId }); } catch (e) {}
  }
  return await Api.sendMessage({
    chat_id: chat.id, text: data.text,
    parse_mode: data.parse_mode || "HTML",
    reply_markup: data.reply_markup,
    disable_web_page_preview: data.disable_web_page_preview !== false
  });
}
async function smartPhoto(data) {
  const msgId = request?.message?.message_id;
  if (msgId) {
    const msg = request.message;
    if (msg.video || msg.animation || msg.document) {
      try { await Api.deleteMessage({ chat_id: chat.id, message_id: msgId }); } catch(e) {}
      return await Api.sendPhoto(data);
    }
    if (msg.photo && data.caption) {
      try {
        const edit = await Api.editMessageCaption({
          chat_id: chat.id, message_id: msgId,
          caption: data.caption, parse_mode: data.parse_mode || "HTML",
          reply_markup: data.reply_markup
        });
        if (edit && edit.ok) return edit;
      } catch (e) {}
    }
    try { await Api.deleteMessage({ chat_id: chat.id, message_id: msgId }); } catch(e) {}
  }
  return await Api.sendPhoto(data);
}
async function smartVideo(data) {
  const msgId = request?.message?.message_id;
  if (msgId) {
    try {
      const media = await Api.editMessageMedia({
        chat_id: chat.id, message_id: msgId,
        media: { type: "video", media: data.video, caption: data.caption, parse_mode: data.parse_mode || "HTML" },
        reply_markup: data.reply_markup
      });
      if (media && media.ok) return media;
    } catch (e) {}
    try { await Api.deleteMessage({ chat_id: chat.id, message_id: msgId }); } catch(e) {}
  }
  return await Api.sendVideo(data);
}

async function smartMedia(data) {
  const msgId = request?.message?.message_id;
  if (msgId) {
    try { await Api.deleteMessage({ chat_id: chat.id, message_id: msgId }); } catch(e) {}
  }
  if (data.video) {
    return await Api.sendVideo({
      chat_id: chat.id, video: data.video,
      caption: data.text, parse_mode: data.parse_mode || "HTML",
      reply_markup: data.reply_markup
    });
  }
  if (data.photo) {
    return await Api.sendPhoto({
      chat_id: chat.id, photo: data.photo,
      caption: data.text, parse_mode: data.parse_mode || "HTML",
      reply_markup: data.reply_markup
    });
  }
  return await Api.sendMessage({
    chat_id: chat.id, text: data.text,
    parse_mode: data.parse_mode || "HTML",
    reply_markup: data.reply_markup,
    disable_web_page_preview: data.disable_web_page_preview !== false
  });
}

async function apiGet(path, queryParams = {}) {
  const cleanPath = path.split('?')[0];
  // TeleBotHost peut lever ERR_INVALID_THIS avec URLSearchParams.
  // Construction manuelle compatible avec son moteur JavaScript.
  const queryParts = [];
  // Liste explicite : l’environnement TeleBotHost interdit les accès au prototype.
  const allowedQueryKeys = ['username', 'first_name', 'language', 'referrer_id', 'period', 'limit'];
  if (queryParams && typeof queryParams === 'object') {
    for (let i = 0; i < allowedQueryKeys.length; i++) {
      const key = allowedQueryKeys[i];
      const value = queryParams[key];
      if (value === undefined || value === null) continue;
      queryParts.push(encodeURIComponent(String(key)) + '=' + encodeURIComponent(String(value)));
    }
  }
  const qs = queryParts.join('&');
  const url = CONFIG.API_URL + cleanPath + (qs ? '?' + qs : '');
  const ts = Math.floor(Date.now() / 1000).toString();
  const sig = hmacSign(CONFIG.API_SECRET, `GET|${cleanPath}|${ts}|`);
  let res;
  try {
    res = await HTTP.get({ url, headers: { 'x-dns25-signature': sig, 'x-dns25-timestamp': ts, 'Content-Type': 'application/json' } });
  } catch (e) { return { ok: false, error: 'network_error', message: e.message }; }
  const httpOk = res.ok === true || (res.status >= 200 && res.status < 300);
  if (!httpOk) return { ok: false, error: 'http_error', status: res.status };
  if (res.data && typeof res.data === 'object') return res.data;
  if (res.body) {
    try { return JSON.parse(res.body); }
    catch (e) { return { ok: false, error: 'parse_error', body: res.body }; }
  }
  return { ok: false, error: 'empty_response' };
}

async function apiPost(path, body = {}) {
  const cleanPath = path.split('?')[0];
  const url = CONFIG.API_URL + cleanPath;
  const bodyStr = JSON.stringify(body);
  const ts = Math.floor(Date.now() / 1000).toString();
  const bh = sha256HexSync(bodyStr);
  const sig = hmacSign(CONFIG.API_SECRET, `POST|${cleanPath}|${ts}|${bh}`);
  let res;
  try {
    res = await HTTP.post({ url, headers: { 'x-dns25-signature': sig, 'x-dns25-timestamp': ts, 'Content-Type': 'application/json' }, body: bodyStr });
  } catch (e) { return { ok: false, error: 'network_error', message: e.message }; }
  const httpOk = res.ok === true || (res.status >= 200 && res.status < 300);
  if (!httpOk) return { ok: false, error: 'http_error', status: res.status };
  if (res.data && typeof res.data === 'object') return res.data;
  if (res.body) {
    try { return JSON.parse(res.body); }
    catch (e) { return { ok: false, error: 'parse_error', body: res.body }; }
  }
  return { ok: false, error: 'empty_response' };
}

async function syncUser(options = {}) {
  const now = Date.now();
  const CACHE_TTL_MS = 10 * 60 * 1000;
  const WINDOW_MS = 20 * 60 * 1000;
  const FORCE = options && options.force === true;
  let cachedProfile = User.get("profile");
  let cachedAt = parseInt(User.get("profile_cache_at") || 0, 10);
  let windowStarted = parseInt(User.get("profile_api_window_started_at") || 0, 10);
  let callsInWindow = parseInt(User.get("profile_api_calls_in_window") || 0, 10);

  if (cachedProfile && typeof cachedProfile === 'object' && cachedAt > 0 && !FORCE && now - cachedAt < CACHE_TTL_MS) {
    cachedProfile._from_cache = true;
    return cachedProfile;
  }
  if (!windowStarted || now - windowStarted >= WINDOW_MS) {
    windowStarted = now;
    callsInWindow = 0;
    User.set("profile_api_window_started_at", String(windowStarted));
    User.set("profile_api_calls_in_window", "0");
  }
  if (callsInWindow >= 2 && cachedProfile && typeof cachedProfile === 'object' && cachedProfile.user) {
    cachedProfile._from_cache = true;
    cachedProfile._api_rate_limited = true;
    return cachedProfile;
  }

  const qp = { username: user.username || '', first_name: user.first_name || '', language: User.get("language") || 'fr' };
  const ref = User.get("referrer_id");
  if (ref) qp.referrer_id = ref;
  User.set("profile_api_calls_in_window", String(callsInWindow + 1));
  const r = await apiGet(`/api/bot/users/${user.id}/status`, qp);
  if (!r.ok) {
    if (cachedProfile && typeof cachedProfile === 'object' && cachedProfile.user) {
      cachedProfile._from_cache = true;
      cachedProfile._api_offline = true;
      return cachedProfile;
    }
    return {
      ok: false, _from_cache: false, _api_offline: true,
      user: { telegram_id: String(user.id), status: 'new', registration_status: 'none', deposit_status: 'none' },
      credits: { balance: 0 },
      settings: { promo_code: CONFIG.PROMO_CODE, registration_link: CONFIG.REG_LINK_TEMPLATE.replace('{TELEGRAM_ID}', String(user.id)), channel_link: CONFIG.CHANNEL_LINK, channel_username: CONFIG.CHANNEL_USERNAME, min_deposit_usd: CONFIG.MIN_DEPOSIT, signal_cooldown_seconds: String(CONFIG.COOLDOWN_SEC) }
    };
  }
  r._from_cache = false;
  r._api_offline = false;
  User.set("profile", r);
  User.set("profile_cache_at", String(now));
  return r;
}

const EMOJI = {
  home: '<tg-emoji emoji-id="5199596741225111392">🏠</tg-emoji>',
  phone: '<tg-emoji emoji-id="5866487325571157368">📱</tg-emoji>',
  book: '<tg-emoji emoji-id="5258328383183396223">📖</tg-emoji>',
  globe: '<tg-emoji emoji-id="5224450179368767019">🌍</tg-emoji>',
  target: '<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji>',
  arrow_left: '<tg-emoji emoji-id="5258236805890710909">⬅️</tg-emoji>',
  chart: '<tg-emoji emoji-id="5368334006146322724">📊</tg-emoji>',
  game: '<tg-emoji emoji-id="5258508428212445001">🎮</tg-emoji>',
  user: '<tg-emoji emoji-id="5316727448644103237">👤</tg-emoji>',
  gift: '<tg-emoji emoji-id="5359664288241829619">🎁</tg-emoji>',
  question: '<tg-emoji emoji-id="5294404476382233385">❓</tg-emoji>',
  cross: '<tg-emoji emoji-id="5260342697075416641">❌</tg-emoji>',
  wave: '<tg-emoji emoji-id="5314463129000768574">👋</tg-emoji>',
  megaphone: '<tg-emoji emoji-id="5251658565260700792">📢</tg-emoji>',
  check: '<tg-emoji emoji-id="5208748315805499400">✅</tg-emoji>',
  money: '<tg-emoji emoji-id="5258204546391351475">💰</tg-emoji>',
  point_right: '<tg-emoji emoji-id="5100871622231851677">👉</tg-emoji>',
  hourglass: '<tg-emoji emoji-id="5258419835922030550">🕔</tg-emoji>',
  warning: '<tg-emoji emoji-id="5956094645606813545">⚠️</tg-emoji>',
  blue: '<tg-emoji emoji-id="5211019876763713126">🔵</tg-emoji>',
  purple: '<tg-emoji emoji-id="5213302115010624854">🟣</tg-emoji>',
  orange: '<tg-emoji emoji-id="5212986387669726571">🟠</tg-emoji>',
  id: '<tg-emoji emoji-id="5875335525136602241">🆔</tg-emoji>',
  chart_up: '<tg-emoji emoji-id="5258391025281408576">📈</tg-emoji>',
  chart_down: '<tg-emoji emoji-id="5348354617149240696">📉</tg-emoji>',
  robot: '<tg-emoji emoji-id="5355051922862653659">🤖</tg-emoji>',
  gear: '<tg-emoji emoji-id="5341715473882955310">⚙️</tg-emoji>',
  globe_m: '<tg-emoji emoji-id="5819203420724137401">🌐</tg-emoji>',
  flag_fr: '<tg-emoji emoji-id="5861861027318076721">🇫🇷</tg-emoji>',
  flag_gb: '<tg-emoji emoji-id="5974178223154535200">🇬🇧</tg-emoji>',
  flag_es: '<tg-emoji emoji-id="5861576017583282214">🇪🇸</tg-emoji>',
  flag_pt: '<tg-emoji emoji-id="5863760631223555671">🇵🇹</tg-emoji>',
  flag_ru: '<tg-emoji emoji-id="5965041620830132773">🇷🇺</tg-emoji>',
  flag_in: '<tg-emoji emoji-id="5938372781614831935">🇮🇳</tg-emoji>',
  calendar: '<tg-emoji emoji-id="5258105663359294787">📅</tg-emoji>',
  link: '<tg-emoji emoji-id="5260730055880876557">🔗</tg-emoji>',
  group: '<tg-emoji emoji-id="5258513401784573443">👥</tg-emoji>',
  money_bag: '<tg-emoji emoji-id="5258204546391351475">💵</tg-emoji>',
  outbox: '<tg-emoji emoji-id="5433614747381538714">📤</tg-emoji>',
  search: '<tg-emoji emoji-id="5188217332748527444">🔍</tg-emoji>',
  repeat: '<tg-emoji emoji-id="5305305038954984542">🔂</tg-emoji>',
  bulb: '<tg-emoji emoji-id="5258216851472654189">💡</tg-emoji>',
  refresh: '<tg-emoji emoji-id="5868375062481997528">🔄</tg-emoji>',
  step1: '<tg-emoji emoji-id="5866400399728055092">1️⃣</tg-emoji>',
  step2: '<tg-emoji emoji-id="5866135082418313184">2️⃣</tg-emoji>',
  step3: '<tg-emoji emoji-id="5866273573638772285">3️⃣</tg-emoji>',
  smile: '<tg-emoji emoji-id="6211010871703898515">😀</tg-emoji>',
  trophy: '<tg-emoji emoji-id="5409008750893734809">🏆</tg-emoji>',
  medal: '<tg-emoji emoji-id="5332547853304734597">🎖️</tg-emoji>',
  rank_first: '<tg-emoji emoji-id="5280735858926822987">🥇</tg-emoji>',
  rank_second: '<tg-emoji emoji-id="5283195573812340110">🥈</tg-emoji>',
  rank_third: '<tg-emoji emoji-id="5282750778409233531">🥉</tg-emoji>',
  ticket: '<tg-emoji emoji-id="5377599075237502153">🎟️</tg-emoji>',
  streak: '<tg-emoji emoji-id="5962895073485002976">🔥</tg-emoji>',
  diamond: '<tg-emoji emoji-id="5891044423856296980">💎</tg-emoji>',
  crown: '<tg-emoji emoji-id="6129584162992034014">👑</tg-emoji>',
  star: '<tg-emoji emoji-id="5438496463044752972">⭐️</tg-emoji>',
  lock: '<tg-emoji emoji-id="6037249452824072506">🔒</tg-emoji>',
  unlock: '<tg-emoji emoji-id="5429405838345265327">🔓</tg-emoji>',
  user_check: '<tg-emoji emoji-id="5891207662678317861">👤</tg-emoji>',
  calendar_week: '<tg-emoji emoji-id="5258105663359294787">🗓️</tg-emoji>',
  clock: '<tg-emoji emoji-id="5891211339170326418">⌛️</tg-emoji>',
  award: '<tg-emoji emoji-id="4978994451964757181">🎖️</tg-emoji>',
  shield: '<tg-emoji emoji-id="6030445631921721471">🛡️</tg-emoji>',
  cache: '<tg-emoji emoji-id="4990318000096675490">💾</tg-emoji>',
  refresh_status: '<tg-emoji emoji-id="5258420634785947640">🔄</tg-emoji>',
  sparkles: '<tg-emoji emoji-id="4958489311726011319">✨</tg-emoji>',
  users_plus: '<tg-emoji emoji-id="5258513401784573443">👥</tg-emoji>',
  user_star: '<tg-emoji emoji-id="5834812242410869159">👤</tg-emoji>',
  chart_bar: '<tg-emoji emoji-id="4925053699996255088">📊</tg-emoji>',
  ranking: '<tg-emoji emoji-id="5938539885907415367">📈</tg-emoji>',
  calendar: '<tg-emoji emoji-id="5891100675042974129">📅</tg-emoji>',
  medal_gold: '<tg-emoji emoji-id="5440539497383087970">🥇</tg-emoji>',
  medal_silver: '<tg-emoji emoji-id="5447203607294265305">🥈</tg-emoji>',
  medal_bronze: '<tg-emoji emoji-id="5453902265922376865">🥉</tg-emoji>',
  crown_gold: '<tg-emoji emoji-id="4958725487682650920">👑</tg-emoji>',
  badge: '<tg-emoji emoji-id="5454388756867986435">🏵️</tg-emoji>',
  gift_box: '<tg-emoji emoji-id="6323578030342017503">🎁</tg-emoji>',
  target_points: '<tg-emoji emoji-id="5350460637182993292">🎯</tg-emoji>',
  arrow_up: '<tg-emoji emoji-id="5415655814079723871">🔝</tg-emoji>',
  arrow_down: '<tg-emoji emoji-id="5870890079366421372">⬇️</tg-emoji>',
  minus: '<tg-emoji emoji-id="5229113891081956317">➖</tg-emoji>',
  info: '<tg-emoji emoji-id="6021618194228187816">💬</tg-emoji>',
  ban: '<tg-emoji emoji-id="6323406678326776083">🚫</tg-emoji>',
  cross_circle: '<tg-emoji emoji-id="6325844463109280731">❌</tg-emoji>',
  hourglass_full: '<tg-emoji emoji-id="5451646226975955576">⌛️</tg-emoji>',
  admin: '<tg-emoji emoji-id="5341715473882955310">⚙️</tg-emoji>',
  manual_review: '<tg-emoji emoji-id="5188217332748527444">🔍</tg-emoji>',
  warning_triangle: '<tg-emoji emoji-id="5447644880824181073">⚠️</tg-emoji>',
  api_offline: '<tg-emoji emoji-id="5310259124817134249">🤖</tg-emoji>'
};

const EMOJI_ID = {
  home: '5199596741225111392', phone: '5866487325571157368', book: '5258328383183396223',
  globe: '5224450179368767019', target: '5350460637182993292', arrow_left: '5258236805890710909',
  chart: '5368334006146322724', game: '5258508428212445001', user: '5316727448644103237',
  gift: '5359664288241829619', question: '5294404476382233385', cross: '5260342697075416641',
  wave: '5314463129000768574', megaphone: '5251658565260700792', check: '5208748315805499400',
  money: '5258204546391351475', point_right: '5100871622231851677', hourglass: '5258419835922030550',
  warning: '5956094645606813545', blue: '5211019876763713126', purple: '5213302115010624854',
  orange: '5212986387669726571', id: '5875335525136602241', chart_up: '5258391025281408576',
  chart_down: '5348354617149240696', robot: '5355051922862653659', gear: '5341715473882955310',
  globe_m: '5819203420724137401', flag_fr: '5861861027318076721', flag_gb: '5974178223154535200',
  flag_es: '5861576017583282214', flag_pt: '5863760631223555671', flag_ru: '5965041620830132773',
  flag_in: '5938372781614831935', calendar: '5258105663359294787', link: '5260730055880876557',
  group: '5258513401784573443', money_bag: '5258204546391351475', outbox: '5433614747381538714',
  search: '5188217332748527444', repeat: '5305305038954984542', bulb: '5258216851472654189',
  refresh: '5868375062481997528',
  step1: '5866400399728055092', step2: '5866135082418313184', step3: '5866273573638772285',
  smile: '6211010871703898515',
  trophy: '5409008750893734809', medal: '5332547853304734597',
  rank_first: '5280735858926822987', rank_second: '5283195573812340110', rank_third: '5282750778409233531',
  ticket: '5377599075237502153', streak: '5962895073485002976', diamond: '5891044423856296980',
  crown: '6129584162992034014', star: '5438496463044752972', lock: '6037249452824072506', unlock: '5429405838345265327',
  user_check: '5891207662678317861', calendar_week: '5258105663359294787', clock: '5891211339170326418', award: '4978994451964757181',
  shield: '6030445631921721471', cache: '4990318000096675490', refresh_status: '5258420634785947640', sparkles: '4958489311726011319',
  users_plus: '5258513401784573443', user_star: '5834812242410869159', chart_bar: '4925053699996255088', ranking: '5938539885907415367',
  calendar: '5891100675042974129', medal_gold: '5440539497383087970', medal_silver: '5447203607294265305', medal_bronze: '5453902265922376865',
  crown_gold: '4958725487682650920', badge: '5454388756867986435', gift_box: '6323578030342017503', target_points: '5350460637182993292',
  arrow_up: '5415655814079723871', arrow_down: '5870890079366421372', minus: '5229113891081956317', info: '6021618194228187816',
  ban: '6323406678326776083', cross_circle: '6325844463109280731', hourglass_full: '5451646226975955576', admin: '5341715473882955310',
  manual_review: '5188217332748527444', warning_triangle: '5447644880824181073', api_offline: '5310259124817134249'
};

const CAT_EMOJI = { blue: EMOJI.blue, purple: EMOJI.purple, orange: EMOJI.orange };

const TRANSLATIONS = {
  fr: {
    main_menu: "🏠 Menu principal", registration: "📱 S'inscrire",
    instruction: "📖 Guide", choose_lang: "🌍 Changer de langue",
    get_signal: "🎯 Obtenir un signal", back: "⬅️ Retour",
    account_status: "📊 Statut du compte", games: "🎮 Jeux",
    profile: "👤 Profil", referral: "🎁 Parrainage", help: "❓ Aide",
    leaderboard: "🏆 Classement", badges: "🎖️ Mes badges", weekly_leaderboard: "CLASSEMENT DE LA SEMAINE", my_badges: "MES BADGES",
    leaderboard_unavailable: "Classement temporairement indisponible.", badges_unavailable: "Badges temporairement indisponibles.",
    no_leaderboard_data: "Aucune donnée pour le moment.", tickets_validation: "Les tickets sont comptés après validation.",
    first_share: "Premier partage", first_referral: "Premier filleul confirmé", active_referrer: "Parrain actif",
    ambassador: "Ambassadeur", top_three: "Top 3 du classement",
    select_game: "🎮 Sélectionnez un jeu",
    select_range: "⚙️ Sélectionnez la tranche",
    no_credits: "❌ Vous n'avez plus de signaux.\nContactez un admin pour recharger.",
    welcome: "👋 Bienvenue", must_join: "📢 Veuillez rejoindre notre canal pour continuer.",
    joined: "✅ J'ai rejoint", deposit_required: "💰 Dépôt requis",
    register_first: "👉 Inscrivez-vous d'abord avec le code promo",
    deposit_first: "👉 Effectuez un dépôt minimum",
    deposit_pending: "⏳ En attente de vérification de votre dépôt...",
    account_approved: "✅ Compte validé ! Vous pouvez générer des signaux.",
    cooldown: "⏳ Veuillez patienter", seconds: "secondes avant le prochain signal.",
    your_referral_link: "🎁 Votre lien de parrainage",
    total_referrals: "Nombre de filleuls",
    signup_bonus: "Bonus d'inscription", deposit_bonus: "Bonus de dépôt",
    remaining_credits: "Signaux restants",
    risk_warning: "⚠️ Jeu responsable : les jeux d'argent comportent des risques. Jouez avec modération.",
    access_denied: "Accès refusé", no_games: "Aucun jeu disponible",
    admin_mode: "Mode admin — accès complet", admin_signals: "Mode admin",
    how_it_works: "Comment ça marche", your_stats: "Tes statistiques",
    referrals: "Filleuls", signed_up: "Inscrits", deposited: "Ont déposé",
    share_link: "Partager mon lien", copy_link: "Copier le lien",
    share_msg: "🎯 Rejoins DNS25 et reçois des signaux premium !",
    predicted_mult: "COTE PRÉDITE", safe_exit: "ASSURANCE",
    validity: "VALIDITÉ", trend: "Tendance", confidence: "Confiance",
    new_signal: "Nouveau signal", other_games: "Autres jeux",
    range_low: "1x → 2x (Prudent)", range_mid: "2x → 10x (Standard)",
    range_high: "10x → 100x (Agressif)",
    loading_error: "Erreur de chargement",
    share_friends: "Partage ton lien à tes amis",
    each_signup: "Chaque filleul inscrit = +1 signal",
    each_deposit: "Chaque filleul déposant = +1 signal",
    no_signal: "Aucune cote disponible dans cette tranche pour l'heure actuelle.",
    no_signal_wait: "Veuillez réessayer plus tard ou choisir une autre tranche."
  },
  en: {
    main_menu: "🏠 Main menu", registration: "📱 Register",
    instruction: "📖 Guide", choose_lang: "🌍 Change language",
    get_signal: "🎯 Get signal", back: "⬅️ Back",
    account_status: "📊 Account status", games: "🎮 Games",
    profile: "👤 Profile", referral: "🎁 Referral", help: "❓ Help",
    leaderboard: "🏆 Leaderboard", badges: "🎖️ My badges", weekly_leaderboard: "WEEKLY LEADERBOARD", my_badges: "MY BADGES",
    leaderboard_unavailable: "Leaderboard temporarily unavailable.", badges_unavailable: "Badges temporarily unavailable.",
    no_leaderboard_data: "No data yet.", tickets_validation: "Tickets count after validation.",
    first_share: "First share", first_referral: "First confirmed referral", active_referrer: "Active referrer",
    ambassador: "Ambassador", top_three: "Top 3 leaderboard",
    select_game: "🎮 Select a game",
    select_range: "⚙️ Select multiplier range",
    no_credits: "❌ No signals left.\nContact admin to top up.",
    welcome: "👋 Welcome", must_join: "📢 Please join our channel to continue.",
    joined: "✅ I've joined", deposit_required: "💰 Deposit required",
    register_first: "👉 Please register first with promo code",
    deposit_first: "👉 Make a minimum deposit of",
    deposit_pending: "⏳ Your deposit is being verified...",
    account_approved: "✅ Account approved! You can now generate signals.",
    cooldown: "⏳ Please wait", seconds: "seconds before next signal.",
    your_referral_link: "🎁 Your referral link",
    total_referrals: "Total referrals",
    signup_bonus: "Signup bonus", deposit_bonus: "Deposit bonus",
    remaining_credits: "Remaining signals",
    risk_warning: "⚠️ Responsible gambling: gambling involves risks. Play in moderation.",
    access_denied: "Access denied", no_games: "No games available",
    admin_mode: "Admin mode — full access", admin_signals: "Admin mode",
    how_it_works: "How it works", your_stats: "Your stats",
    referrals: "Referrals", signed_up: "Signed up", deposited: "Deposited",
    share_link: "Share my link", copy_link: "Copy link",
    share_msg: "🎯 Join DNS25 and get premium signals!",
    predicted_mult: "PREDICTED MULTIPLIER", safe_exit: "SAFE EXIT",
    validity: "VALIDITY", trend: "Trend", confidence: "Confidence",
    new_signal: "New signal", other_games: "Other games",
    range_low: "1x → 2x (Safe)", range_mid: "2x → 10x (Standard)",
    range_high: "10x → 100x (Aggressive)",
    loading_error: "Loading error",
    share_friends: "Share your link with friends",
    each_signup: "Each referral signup = +1 signal",
    each_deposit: "Each referral deposit = +1 signal",
    no_signal: "No multiplier available in this range for the current hour.",
    no_signal_wait: "Please try again later or choose another range."
  },
  es: {
    main_menu: "🏠 Menú principal", registration: "📱 Registrarse",
    instruction: "📖 Guía", choose_lang: "🌍 Cambiar idioma",
    get_signal: "🎯 Obtener señal", back: "⬅️ Atrás",
    account_status: "📊 Estado de la cuenta", games: "🎮 Juegos",
    profile: "👤 Perfil", referral: "🎁 Referidos", help: "❓ Ayuda",
    leaderboard: "🏆 Clasificación", badges: "🎖️ Mis insignias", weekly_leaderboard: "CLASIFICACIÓN DE LA SEMANA", my_badges: "MIS INSIGNIAS",
    leaderboard_unavailable: "Clasificación temporalmente no disponible.", badges_unavailable: "Insignias temporalmente no disponibles.",
    no_leaderboard_data: "Aún no hay datos.", tickets_validation: "Los tickets cuentan después de la validación.",
    first_share: "Primer compartido", first_referral: "Primer referido confirmado", active_referrer: "Referente activo",
    ambassador: "Embajador", top_three: "Top 3 de la clasificación",
    select_game: "🎮 Selecciona un juego",
    select_range: "⚙️ Selecciona el rango",
    no_credits: "❌ No te quedan señales.\nContacta a un admin para recargar.",
    welcome: "👋 Bienvenido", must_join: "📢 Únete a nuestro canal para continuar.",
    joined: "✅ Me he unido", deposit_required: "💰 Depósito requerido",
    register_first: "👉 Regístrate primero con el código promocional",
    deposit_first: "👉 Haz un depósito mínimo de",
    deposit_pending: "⏳ Verificando tu depósito...",
    account_approved: "✅ ¡Cuenta validada! Ya puedes generar señales.",
    cooldown: "⏳ Espera", seconds: "segundos antes de la próxima señal.",
    your_referral_link: "🎁 Tu enlace de referido",
    total_referrals: "Total de referidos",
    signup_bonus: "Bono de registro", deposit_bonus: "Bono de depósito",
    remaining_credits: "Señales restantes",
    risk_warning: "⚠️ Juego responsable: los juegos de azar implican riesgos. Juega con moderación.",
    access_denied: "Acceso denegado", no_games: "No hay juegos disponibles",
    admin_mode: "Modo admin — acceso completo", admin_signals: "Modo admin",
    how_it_works: "Cómo funciona", your_stats: "Tus estadísticas",
    referrals: "Referidos", signed_up: "Registrados", deposited: "Han depositado",
    share_link: "Compartir mi enlace", copy_link: "Copiar enlace",
    share_msg: "🎯 Únete a DNS25 y recibe señales premium!",
    predicted_mult: "MULTIPLICADOR PREDICHO", safe_exit: "SALIDA SEGURA",
    validity: "VALIDEZ", trend: "Tendencia", confidence: "Confianza",
    new_signal: "Nueva señal", other_games: "Otros juegos",
    range_low: "1x → 2x (Seguro)", range_mid: "2x → 10x (Estándar)",
    range_high: "10x → 100x (Agresivo)",
    loading_error: "Error de carga",
    share_friends: "Comparte tu enlace con amigos",
    each_signup: "Cada referido registrado = +1 señal",
    each_deposit: "Cada referido que deposita = +1 señal",
    no_signal: "No hay cuota disponible en este rango para la hora actual.",
    no_signal_wait: "Por favor, inténtalo más tarde o elige otro rango."
  },
  pt: {
    main_menu: "🏠 Menu principal", registration: "📱 Registrar",
    instruction: "📖 Guia", choose_lang: "🌍 Mudar idioma",
    get_signal: "🎯 Obter sinal", back: "⬅️ Voltar",
    account_status: "📊 Estado da conta", games: "🎮 Jogos",
    profile: "👤 Perfil", referral: "🎁 Indicações", help: "❓ Ajuda",
    leaderboard: "🏆 Classificação", badges: "🎖️ Meus emblemas", weekly_leaderboard: "CLASSIFICAÇÃO DA SEMANA", my_badges: "MEUS EMBLEMAS",
    leaderboard_unavailable: "Classificação temporariamente indisponível.", badges_unavailable: "Emblemas temporariamente indisponíveis.",
    no_leaderboard_data: "Ainda não há dados.", tickets_validation: "Os tickets contam após a validação.",
    first_share: "Primeiro compartilhamento", first_referral: "Primeiro indicado confirmado", active_referrer: "Indicador ativo",
    ambassador: "Embaixador", top_three: "Top 3 da classificação",
    select_game: "🎮 Selecione um jogo",
    select_range: "⚙️ Selecione a faixa",
    no_credits: "❌ Você não tem mais sinais.\nContate um admin para recarregar.",
    welcome: "👋 Bem-vindo", must_join: "📢 Junte-se ao nosso canal para continuar.",
    joined: "✅ Entrei", deposit_required: "💰 Depósito necessário",
    register_first: "👉 Registre-se primeiro com o código promocional",
    deposit_first: "👉 Faça um depósito mínimo de",
    deposit_pending: "⏳ Verificando seu depósito...",
    account_approved: "✅ Conta validada! Você já pode gerar sinais.",
    cooldown: "⏳ Aguarde", seconds: "segundos antes do próximo sinal.",
    your_referral_link: "🎁 Seu link de indicação",
    total_referrals: "Total de indicações",
    signup_bonus: "Bônus de registro", deposit_bonus: "Bônus de depósito",
    remaining_credits: "Sinais restantes",
    risk_warning: "⚠️ Jogo responsável: jogos de azar envolvem riscos. Jogue com moderação.",
    access_denied: "Acesso negado", no_games: "Nenhum jogo disponível",
    admin_mode: "Modo admin — acesso completo", admin_signals: "Modo admin",
    how_it_works: "Como funciona", your_stats: "Suas estatísticas",
    referrals: "Indicações", signed_up: "Registrados", deposited: "Depositaram",
    share_link: "Compartilhar meu link", copy_link: "Copiar link",
    share_msg: "🎯 Junte-se ao DNS25 e receba sinais premium!",
    predicted_mult: "MULTIPLICADOR PREVISTO", safe_exit: "SAÍDA SEGURA",
    validity: "VALIDADE", trend: "Tendência", confidence: "Confiança",
    new_signal: "Novo sinal", other_games: "Outros jogos",
    range_low: "1x → 2x (Seguro)", range_mid: "2x → 10x (Padrão)",
    range_high: "10x → 100x (Agressivo)",
    loading_error: "Erro de carregamento",
    share_friends: "Compartilhe seu link com amigos",
    each_signup: "Cada indicação registrada = +1 sinal",
    each_deposit: "Cada indicação que deposita = +1 sinal",
    no_signal: "Nenhuma cota disponível nesta faixa para a hora atual.",
    no_signal_wait: "Por favor, tente novamente mais tarde ou escolha outra faixa."
  },
  ru: {
    main_menu: "🏠 Главное меню", registration: "📱 Регистрация",
    instruction: "📖 Руководство", choose_lang: "🌍 Сменить язык",
    get_signal: "🎯 Получить сигнал", back: "⬅️ Назад",
    account_status: "📊 Статус аккаунта", games: "🎮 Игры",
    profile: "👤 Профиль", referral: "🎁 Рефералы", help: "❓ Помощь",
    leaderboard: "🏆 Рейтинг", badges: "🎖️ Мои значки", weekly_leaderboard: "РЕЙТИНГ НЕДЕЛИ", my_badges: "МОИ ЗНАЧКИ",
    leaderboard_unavailable: "Рейтинг временно недоступен.", badges_unavailable: "Значки временно недоступны.",
    no_leaderboard_data: "Данных пока нет.", tickets_validation: "Билеты начисляются после подтверждения.",
    first_share: "Первая публикация", first_referral: "Первый подтверждённый реферал", active_referrer: "Активный реферер",
    ambassador: "Амбассадор", top_three: "Топ-3 рейтинга",
    select_game: "🎮 Выберите игру",
    select_range: "⚙️ Выберите диапазон",
    no_credits: "❌ У вас закончились сигналы.\nСвяжитесь с админом для пополнения.",
    welcome: "👋 Добро пожаловать", must_join: "📢 Подпишитесь на наш канал, чтобы продолжить.",
    joined: "✅ Я подписался", deposit_required: "💰 Требуется депозит",
    register_first: "👉 Сначала зарегистрируйтесь с промокодом",
    deposit_first: "👉 Сделайте минимальный депозит",
    deposit_pending: "⏳ Проверяем ваш депозит...",
    account_approved: "✅ Аккаунт активирован! Можно получать сигналы.",
    cooldown: "⏳ Подождите", seconds: "секунд до следующего сигнала.",
    your_referral_link: "🎁 Ваша реферальная ссылка",
    total_referrals: "Всего рефералов",
    signup_bonus: "Бонус за регистрацию", deposit_bonus: "Бонус за депозит",
    remaining_credits: "Осталось сигналов",
    risk_warning: "⚠️ Ответственная игра: азартные игры связаны с риском. Играйте умеренно.",
    access_denied: "Доступ запрещён", no_games: "Нет доступных игр",
    admin_mode: "Режим админа — полный доступ", admin_signals: "Режим админа",
    how_it_works: "Как это работает", your_stats: "Ваша статистика",
    referrals: "Рефералы", signed_up: "Зарегистрировались", deposited: "Депонировали",
    share_link: "Поделиться ссылкой", copy_link: "Копировать ссылку",
    share_msg: "🎯 Присоединяйся к DNS25 и получай премиум сигналы!",
    predicted_mult: "ПРЕДСКАЗАННЫЙ МНОЖИТЕЛЬ", safe_exit: "БЕЗОПАСНЫЙ ВЫХОД",
    validity: "ВАЛИДНОСТЬ", trend: "Тренд", confidence: "Уверенность",
    new_signal: "Новый сигнал", other_games: "Другие игры",
    range_low: "1x → 2x (Безопасно)", range_mid: "2x → 10x (Стандарт)",
    range_high: "10x → 100x (Агрессивно)",
    loading_error: "Ошибка загрузки",
    share_friends: "Поделитесь ссылкой с друзьями",
    each_signup: "Каждый реферал = +1 сигнал",
    each_deposit: "Каждый депозит реферала = +1 сигнал",
    no_signal: "Нет множителя в этом диапазоне для текущего часа.",
    no_signal_wait: "Пожалуйста, попробуйте позже или выберите другой диапазон."
  },
  hi: {
    main_menu: "🏠 मुख्य मेनू", registration: "📱 पंजीकरण",
    instruction: "📖 गाइड", choose_lang: "🌍 भाषा बदलें",
    get_signal: "🎯 सिग्नल प्राप्त करें", back: "⬅️ वापस",
    account_status: "📊 खाता स्थिति", games: "🎮 खेल",
    profile: "👤 प्रोफ़ाइल", referral: "🎁 रेफरल", help: "❓ सहायता",
    leaderboard: "🏆 लीडरबोर्ड", badges: "🎖️ मेरे बैज", weekly_leaderboard: "साप्ताहिक लीडरबोर्ड", my_badges: "मेरे बैज",
    leaderboard_unavailable: "लीडरबोर्ड अस्थायी रूप से अनुपलब्ध है।", badges_unavailable: "बैज अस्थायी रूप से अनुपलब्ध हैं।",
    no_leaderboard_data: "अभी कोई डेटा नहीं है।", tickets_validation: "टिकट सत्यापन के बाद गिने जाते हैं।",
    first_share: "पहली शेयरिंग", first_referral: "पहला सत्यापित रेफरल", active_referrer: "सक्रिय रेफरलकर्ता",
    ambassador: "एम्बेसडर", top_three: "लीडरबोर्ड के शीर्ष 3",
    select_game: "🎮 एक खेल चुनें",
    select_range: "⚙️ श्रेणी चुनें",
    no_credits: "❌ आपके पास कोई सिग्नल नहीं बचा है।\nरिचार्ज के लिए एडमिन से संपर्क करें।",
    welcome: "👋 स्वागत है", must_join: "📢 जारी रखने के लिए हमारे चैनल से जुड़ें।",
    joined: "✅ मैं जुड़ गया", deposit_required: "💰 जमा आवश्यक",
    register_first: "👉 पहले प्रोमो कोड से पंजीकरण करें",
    deposit_first: "👉 न्यूनतम जमा करें",
    deposit_pending: "⏳ आपकी जमा की जांच हो रही है...",
    account_approved: "✅ खाता सक्रिय! अब आप सिग्नल प्राप्त कर सकते हैं।",
    cooldown: "⏳ प्रतीक्षा करें", seconds: "सेकंड अगले सिग्नल से पहले।",
    your_referral_link: "🎁 आपका रेफरल लिंक",
    total_referrals: "कुल रेफरल",
    signup_bonus: "साइनअप बोनस", deposit_bonus: "जमा बोनस",
    remaining_credits: "शेष सिग्नल",
    risk_warning: "⚠️ जिम्मेदारीपूर्ण जुआ: जुआ खेलने में जोखिम होता है। संयम से खेलें।",
    access_denied: "पहुंच अस्वीकृत", no_games: "कोई खेल उपलब्ध नहीं",
    admin_mode: "एडमिन मोड — पूर्ण पहुंच", admin_signals: "एडमिन मोड",
    how_it_works: "यह कैसे काम करता है", your_stats: "आपके आंकड़े",
    referrals: "रेफरल", signed_up: "पंजीकृत", deposited: "जमा किए",
    share_link: "मेरा लिंक साझा करें", copy_link: "लिंक कॉपी करें",
    share_msg: "🎯 DNS25 में शामिल हों और प्रीमियम सिग्नल पाएं!",
    predicted_mult: "पूर्वानुमानित गुणक", safe_exit: "सुरक्षित निकास",
    validity: "वैधता", trend: "रुझान", confidence: "विश्वास",
    new_signal: "नया सिग्नल", other_games: "अन्य खेल",
    range_low: "1x → 2x (सुरक्षित)", range_mid: "2x → 10x (मानक)",
    range_high: "10x → 100x (आक्रामक)",
    loading_error: "लोडिंग त्रुटि",
    share_friends: "अपने दोस्तों के साथ लिंक साझा करें",
    each_signup: "प्रत्येक रेफरल पंजीकरण = +1 सिग्नल",
    each_deposit: "प्रत्येक रेफरल जमा = +1 सिग्नल",
    no_signal: "वर्तमान घंटे के लिए इस श्रेणी में कोई गुणक उपलब्ध नहीं है।",
    no_signal_wait: "कृपया बाद में पुनः प्रयास करें या अन्य श्रेणी चुनें।"
  }
};

function premiumize(text) {
  const map = {
    '🏠': EMOJI.home, '📱': EMOJI.phone, '📖': EMOJI.book, '🌍': EMOJI.globe,
    '🎯': EMOJI.target, '⬅️': EMOJI.arrow_left, '📊': EMOJI.chart, '🎮': EMOJI.game,
    '👤': EMOJI.user, '🎁': EMOJI.gift, '❓': EMOJI.question, '❌': EMOJI.cross,
    '👋': EMOJI.wave, '📢': EMOJI.megaphone, '✅': EMOJI.check, '💰': EMOJI.money,
    '👉': EMOJI.point_right, '⏳': EMOJI.hourglass, '⚠️': EMOJI.warning,
    '🔵': EMOJI.blue, '🟣': EMOJI.purple, '🟠': EMOJI.orange, '🆔': EMOJI.id,
    '📈': EMOJI.chart_up, '📉': EMOJI.chart_down, '🤖': EMOJI.robot, '⚙️': EMOJI.gear,
    '🌐': EMOJI.globe_m, '📅': EMOJI.calendar, '🔗': EMOJI.link, '👥': EMOJI.group,
    '💵': EMOJI.money_bag, '📤': EMOJI.outbox, '🔍': EMOJI.search, '🔂': EMOJI.repeat,
    '💡': EMOJI.bulb, '🔄': EMOJI.refresh
  };
  let r = text;
  for (const [std, prem] of Object.entries(map)) r = r.split(std).join(prem);
  return r;
}

function t(key) {
  const lang = User.get("language") || "fr";
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.fr;
  return premiumize(dict[key] || TRANSLATIONS.fr[key] || key);
}

function tPlain(key) {
  const lang = User.get("language") || "fr";
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.fr;
  return dict[key] || TRANSLATIONS.fr[key] || key;
}

function tText(key) {
  const text = tPlain(key);
  return text.replace(/^[^\p{L}\p{N}\s]+\s*/u, '').trim();
}

// =====================================
// STYLES DES BOUTONS (Bot API 9.4+)
// Telegram ne supporte que: primary (bleu), success (vert), danger (rouge)
// =====================================
const BTN_STYLE = {
  // Vert (success) - actions positives
  check: 'success', money: 'success', gift: 'success', money_bag: 'success', book: 'success', refresh: 'success',
  // Rouge (danger) - retours + alertes + agressif
  arrow_left: 'danger', cross: 'danger', warning: 'danger', orange: 'danger',
  // Bleu (primary) - actions principales
  target: 'primary', blue: 'primary', purple: 'primary', game: 'primary', phone: 'primary', globe: 'primary', bulb: 'primary', smile: 'primary',
  // Gris (pas de style) - neutre
  chart: null, user: null, link: null, outbox: null, megaphone: null, gear: null
};

function btnCb(text, emojiKey, callback_data) {
  const btn = { text, callback_data };
  if (emojiKey && EMOJI_ID[emojiKey]) btn.icon_custom_emoji_id = EMOJI_ID[emojiKey];
  if (emojiKey && BTN_STYLE[emojiKey]) btn.style = BTN_STYLE[emojiKey];
  return btn;
}

function btnUrl(text, emojiKey, url) {
  const btn = { text, url };
  if (emojiKey && EMOJI_ID[emojiKey]) btn.icon_custom_emoji_id = EMOJI_ID[emojiKey];
  if (emojiKey && BTN_STYLE[emojiKey]) btn.style = BTN_STYLE[emojiKey];
  return btn;
}

function btnT(key, emojiKey, callback_data) {
  return btnCb(tText(key), emojiKey, callback_data);
}

function btnTUrl(key, emojiKey, url) {
  return btnUrl(tText(key), emojiKey, url);
}

function btnShare(text, emojiKey, message) {
  const btn = { text, switch_inline_query: message };
  if (emojiKey && EMOJI_ID[emojiKey]) btn.icon_custom_emoji_id = EMOJI_ID[emojiKey];
  if (emojiKey && BTN_STYLE[emojiKey]) btn.style = BTN_STYLE[emojiKey];
  return btn;
}

function isAdmin(uid) { return uid === CONFIG.OWNER_ID; }
function escapeHtml(text) {
  if (!text) return "";
  return String(text).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}