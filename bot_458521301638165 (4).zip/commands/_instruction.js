/**#command
name: /instruction
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /instruction
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let lang = User.get("language") || "fr";

const texts = {
  fr: `${EMOJI.robot} <b>DNS25 — Guide rapide</b>

 ${EMOJI.chart} <b>Outil d'aide à la décision</b> basé sur l'analyse de 1.08M de rounds. Signaux en temps réel — cote prédite, assurance, tendance.

 ${EMOJI.target} <b>Activation en 3 étapes :</b>
 ${EMOJI.step1} Inscris-toi avec le code <b>${CONFIG.PROMO_CODE}</b>
 ${EMOJI.step2} Dépose minimum <b>$${CONFIG.MIN_DEPOSIT} = 3000FCFA</b> 
 ${EMOJI.step3} Reçois tes signaux bonus

 ${EMOJI.money_bag} <b>Bonus dépôt :</b> 1$ déposé = 1 signal
 ${EMOJI.gift} <b>Parrainage :</b> 1 filleul inscrit = 1 signal, 1 filleul déposant = 1 signal

 ${EMOJI.warning} <i>Jeu responsable. Aucune garantie de gain.</i>`,

  en: `${EMOJI.robot} <b>DNS25 — Quick Guide</b>

 ${EMOJI.chart} <b>Decision support tool</b> based on 1.08M rounds analysis. Real-time signals — predicted multiplier, safe exit, trend.

 ${EMOJI.target} <b>Activation in 3 steps:</b>
 ${EMOJI.step1} Register with code <b>${CONFIG.PROMO_CODE}</b>
 ${EMOJI.step2} Deposit minimum <b>$${CONFIG.MIN_DEPOSIT}</b>
 ${EMOJI.step3} Get your bonus signals

 ${EMOJI.money_bag} <b>Deposit bonus:</b> 1$ deposited = 1 signal
 ${EMOJI.gift} <b>Referral:</b> 1 signup = 1 signal, 1 deposit = 1 signal

 ${EMOJI.warning} <i>Responsible gambling. No guarantee of winnings.</i>`,

  es: `${EMOJI.robot} <b>DNS25 — Guía rápida</b>

 ${EMOJI.chart} <b>Herramienta de apoyo</b> basada en análisis de 1.08M rondas. Señales en tiempo real — multiplicador predicho, salida segura, tendencia.

 ${EMOJI.target} <b>Activación en 3 pasos:</b>
 ${EMOJI.step1} Regístrate con el código <b>${CONFIG.PROMO_CODE}</b>
 ${EMOJI.step2} Deposita mínimo <b>$${CONFIG.MIN_DEPOSIT}</b>
 ${EMOJI.step3} Recibe tus señales bonus

 ${EMOJI.money_bag} <b>Bonus depósito:</b> 1$ depositado = 1 señal
 ${EMOJI.gift} <b>Referidos:</b> 1 registro = 1 señal, 1 depósito = 1 señal

 ${EMOJI.warning} <i>Juego responsable. Sin garantía de ganancias.</i>`,

  pt: `${EMOJI.robot} <b>DNS25 — Guia rápido</b>

 ${EMOJI.chart} <b>Ferramenta de apoio</b> baseada na análise de 1.08M rodadas. Sinais em tempo real — multiplicador predito, saída segura, tendência.

 ${EMOJI.target} <b>Ativação em 3 passos:</b>
 ${EMOJI.step1} Registra-te com o código <b>${CONFIG.PROMO_CODE}</b>
 ${EMOJI.step2} Deposita mínimo <b>$${CONFIG.MIN_DEPOSIT}</b>
 ${EMOJI.step3} Recebe tus sinais bônus

 ${EMOJI.money_bag} <b>Bônus depósito:</b> 1$ depositado = 1 sinal
 ${EMOJI.gift} <b>Indicações:</b> 1 registro = 1 sinal, 1 depósito = 1 sinal

 ${EMOJI.warning} <i>Jogo responsável. Sem garantia de ganhos.</i>`,

  ru: `${EMOJI.robot} <b>DNS25 — Краткое руководство</b>

 ${EMOJI.chart} <b>Инструмент поддержки решений</b> на основе анализа 1.08M раундов. Сигналы в реальном времени — предсказанный множитель, безопасный выход, тренд.

 ${EMOJI.target} <b>Активация за 3 шага:</b>
 ${EMOJI.step1} Зарегистрируйся с промокодом <b>${CONFIG.PROMO_CODE}</b>
 ${EMOJI.step2} Депозит от <b>$${CONFIG.MIN_DEPOSIT}</b>
 ${EMOJI.step3} Получи бонусные сигналы

 ${EMOJI.money_bag} <b>Бонус за депозит:</b> 1$ депозита = 1 сигнал
 ${EMOJI.gift} <b>Рефералы:</b> 1 регистрация = 1 сигнал, 1 депозит = 1 сигнал

 ${EMOJI.warning} <i>Ответственная игра. Без гарантии выигрыша.</i>`,

  hi: `${EMOJI.robot} <b>DNS25 — त्वरित गाइड</b>

 ${EMOJI.chart} <b>निर्णय सहायता उपकरण</b> 1.08M राउंड के विश्लेषण पर आधारित। रियल-टाइम सिग्नल — अनुमानित गुणक, सुरक्षित निकास, रुझान।

 ${EMOJI.target} <b>3 चरणों में सक्रियकरण:</b>
 ${EMOJI.step1} कोड <b>${CONFIG.PROMO_CODE}</b> के साथ पंजीकरण करें
 ${EMOJI.step2} न्यूनतम <b>$${CONFIG.MIN_DEPOSIT}</b> जमा करें
 ${EMOJI.step3} अपने बोनस सिग्नल प्राप्त करें

 ${EMOJI.money_bag} <b>जमा बोनस:</b> 1$ जमा = 1 सिग्नल
 ${EMOJI.gift} <b>रेफरल:</b> 1 पंजीकरण = 1 सिग्नल, 1 जमा = 1 सिग्नल

 ${EMOJI.warning} <i>जिम्मेदारीपूर्वक खेलें। कोई जीत की गारंटी नहीं।</i>`
};

let txt = texts[lang] || texts.fr;
let kb = [[btnT("back", "arrow_left", "/main")]];

smartMedia({
  text: txt,
  video: CONFIG.INSTRUCTION_VIDEO || undefined,
  photo: !CONFIG.INSTRUCTION_VIDEO ? (CONFIG.INSTRUCTION_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: kb }
});