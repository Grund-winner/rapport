/**#command
name: /profile
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /profile
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let profile = await syncUser();
let lang = User.get("language") || "fr";

let u = profile.user || {};
let credits = profile.credits?.balance || 0;
let lifetimeEarned = profile.credits?.lifetime_earned || 0;
let lifetimeUsed = profile.credits?.lifetime_used || 0;

let txt = `${EMOJI.user} <b>${t("profile")}</b>\n\n`;
txt += `━━━━━━━━━━━━━━━━━━\n`;
txt += `${EMOJI.id} Telegram: <code>${u.telegram_id || user.id}</code>\n`;
txt += `${EMOJI.user} ${lang === "fr" ? "Nom" : "Name"}: <b>${escapeHtml(u.first_name || user.first_name || "—")}</b>\n`;
txt += `${EMOJI.globe_m} ${lang === "fr" ? "Langue" : "Language"}: ${lang}\n`;
txt += `${EMOJI.globe} ${lang === "fr" ? "Pays" : "Country"}: ${u.country || "—"}\n`;
txt += `${EMOJI.id} 1Win: <code>${u.one_win_user_id || "—"}</code>\n`;
txt += `━━━━━━━━━━━━━━━━━━\n\n`;

txt += `${EMOJI.chart} <b>${lang === "fr" ? "Statut" : "Status"}:</b>\n`;
txt += `${u.registration_status === "registered" ? EMOJI.check : EMOJI.cross} ${lang === "fr" ? "Inscription" : "Registration"}\n`;
txt += `${u.deposit_status === "deposited" ? EMOJI.check : EMOJI.cross} ${lang === "fr" ? "Dépôt" : "Deposit"}\n\n`;

txt += `${EMOJI.target} <b>${lang === "fr" ? "Crédits" : "Credits"}:</b>\n`;
txt += `   ${lang === "fr" ? "Solde actuel" : "Current balance"}: <b>${credits}</b>\n`;
txt += `   ${EMOJI.chart_up} ${lang === "fr" ? "Total reçu" : "Total earned"}: ${lifetimeEarned}\n`;
txt += `   ${EMOJI.chart_down} ${lang === "fr" ? "Total utilisé" : "Total used"}: ${lifetimeUsed}\n\n`;

txt += `${EMOJI.calendar} ${lang === "fr" ? "Inscrit le" : "Joined"}: ${u.created_at ? new Date(u.created_at).toLocaleDateString(lang) : "—"}\n`;

let kb = [[btnT("back", "arrow_left", "/main")]];

smartMedia({
  text: txt,
  video: CONFIG.PROFILE_VIDEO || undefined,
  photo: !CONFIG.PROFILE_VIDEO ? (CONFIG.PROFILE_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: kb }
});