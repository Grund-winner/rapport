/**#command
name: /main
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /main
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /main
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /main
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let profile = await syncUser();
let lang = User.get("language") || "fr";

let registered = profile.user?.registration_status === "registered";
let deposited = profile.user?.deposit_status === "deposited";
let credits = profile.credits?.balance || 0;
let freeUsed = Math.max(0, parseInt(User.get("free_signals_used") || 0, 10));
let freeRemaining = Math.max(0, 3 - freeUsed);
let trialAvailable = freeRemaining > 0 && (!registered || !deposited);

let caption = `<b>${t("main_menu")}</b>\n\n`;
caption += `${EMOJI.user} <b>${escapeHtml(user.first_name || "User")}</b> | ${EMOJI.id} <code>${user.id}</code>\n`;
caption += `${EMOJI.target} ${t("remaining_credits")}: <b>${credits}</b>\n`;
if (trialAvailable) caption += `${EMOJI.gift} <b>${lang === "fr" ? "Signaux gratuits restants" : "Free signals remaining"}: ${freeRemaining}</b>\n\n`;
else caption += `\n`;

if (registered && deposited) {
  caption += `${EMOJI.check} ${t("account_approved")}\n`;
} else if (registered && !deposited) {
  caption += `${EMOJI.warning} ${t("deposit_required")} (${t("deposit_first")} $${CONFIG.MIN_DEPOSIT})\n`;
} else {
  caption += `${EMOJI.cross} ${t("register_first")} <b>${CONFIG.PROMO_CODE}</b>\n`;
}

caption += `\n<i>${t("risk_warning")}</i>`;

let keyboard = [];
keyboard.push([btnT("games", "game", "/games")]);

if (!registered) {
  keyboard.push([
    btnTUrl("registration", "phone", CONFIG.REG_LINK_TEMPLATE.replace("{TELEGRAM_ID}", String(user.id))),
    btnT("instruction", "book", "/instruction")
  ]);
} else if (!deposited) {
  keyboard.push([
    btnUrl(lang === "fr" ? "Déposer" : "Deposit", "money", CONFIG.REG_LINK_TEMPLATE.replace("{TELEGRAM_ID}", String(user.id))),
    btnT("instruction", "book", "/instruction")
  ]);
} else {
  keyboard.push([
    btnT("account_status", "chart", "/account_status"),
    btnT("instruction", "book", "/instruction")
  ]);
}

keyboard.push([
  btnT("profile", "user", "/profile"),
  btnT("referral", "gift", "/referral")
]);

keyboard.push([
  btnCb(tText("leaderboard"), "trophy", "/leaderboard"),
  btnCb(tText("badges"), "medal", "/badges")
]);
keyboard.push([btnT("choose_lang", "globe", "/language")]);

smartMedia({
  text: caption,
  video: CONFIG.MAIN_MENU_VIDEO || undefined,
  photo: !CONFIG.MAIN_MENU_VIDEO ? (CONFIG.MAIN_MENU_IMAGE || undefined) : undefined,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: keyboard }
});