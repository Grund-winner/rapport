/**#command
name: /verify_join
answer: 
keyboard: 
parse_mode: markdown
aliases: 
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

/**#command
name: /verify_join
answer:
keyboard:
parse_mode: markdown
aliases:
allow_only_group: false
need_reply: 0
case_insensitive: false
is_web: 0
#command**/

let joined = false;
try {
  let res = await Api.getChatMember({
    chat_id: CONFIG.CHANNEL_USERNAME,
    user_id: user.id
  });
  joined = ["member", "administrator", "creator"].includes(res.result.status);
} catch (e) { joined = false; }

if (!joined) {
  return Api.answerCallbackQuery({
    callback_query_id: request.id,
    text: "❌ " + (User.get("language") === "en" ? "Please join the channel first" : "Veuillez d'abord rejoindre le canal"),
    show_alert: true
  });
}

User.set("joined_channel_at", String(Date.now()));

Api.answerCallbackQuery({
  callback_query_id: request.id,
  text: "✅ " + (User.get("language") === "en" ? "Joined" : "Rejoint")
});

try {
  await Api.deleteMessage({ chat_id: chat.id, message_id: request.message.message_id });
} catch (e) {}

let lang = User.get("language");
if (!lang) Bot.runCommand("/language");
else Bot.runCommand("/main");